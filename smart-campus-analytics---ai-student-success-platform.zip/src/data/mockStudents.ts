import { Student, SubjectGrade, SkillRating, Intervention } from '../types/student';
import {
  calculateSubScores,
  determineRisks,
  determineSegment,
  generateExplainableFactors,
} from '../utils/analyticsEngine';

// Seeded avatars for authentic student representation
const AVATARS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1548142813-c348350df52b?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=200&q=80',
  'https://images.unsplash.com/photo-1517462964-21fdcec3f25b?auto=format&fit=crop&w=200&q=80',
];

const FIRST_NAMES = [
  'Aarav', 'Ananya', 'Kabir', 'Rohan', 'Diya', 'Siddharth', 'Meera', 'Vikram', 'Tanvi', 'Karthik',
  'Pooja', 'Ishaan', 'Devika', 'Nikhil', 'Sameer', 'Sneha', 'Arjun', 'Priya', 'Aditya', 'Rhea',
  'Harish', 'Neha', 'Varun', 'Anika', 'Rishabh', 'Swati', 'Pranav', 'Shreya', 'Manish', 'Pallavi',
  'Tarun', 'Kavya', 'Gaurav', 'Divya', 'Chirag', 'Ritu', 'Kunal', 'Akanksha', 'Yash', 'Sanya',
  'Aman', 'Shruti', 'Vivek', 'Sanjana', 'Abhinav', 'Deepa', 'Tushar', 'Bhavna', 'Alok', 'Namrata',
  'Mayank', 'Isha', 'Sachin', 'Komal', 'Rahul', 'Nandini', 'Gautam', 'Kritika', 'Suraj', 'Monika',
  'Deepak', 'Aparna', 'Vikas', 'Rashmi', 'Manoj', 'Preeti', 'Rajesh', 'Shweta', 'Sanjay', 'Geeta',
  'Hemant', 'Sunita', 'Dinesh', 'Anita', 'Vinay', 'Payal', 'Sunil', 'Jyoti', 'Ajay', 'Rekha',
  'Ashok', 'Seema', 'Mahesh', 'Usha', 'Naresh', 'Meena', 'Pankaj', 'Suman', 'Rakesh', 'Sarita',
  'Chetan', 'Sandhya', 'Lalit', 'Pushpa', 'Mukesh', 'Archana', 'Naveen', 'Rupal', 'Satish', 'Varsha'
];

const LAST_NAMES = [
  'Sharma', 'Deshmukh', 'Verma', 'Mehra', 'Krishnan', 'Iyer', 'Nair', 'Choudhury', 'Agarwal', 'Raja',
  'Hegde', 'Gupta', 'Pillai', 'Rathi', 'Kulkarni', 'Banerjee', 'Reddy', 'Patel', 'Rao', 'Sen',
  'Sundaram', 'Kapoor', 'Joshi', 'Menon', 'Pandey', 'Mukherjee', 'Das', 'Tiwari', 'Ghosh', 'Bajaj',
  'Nambiar', 'Seth', 'Murthy', 'Singhal', 'Saxena', 'Bhatia', 'Bose', 'Chauhan', 'Malhotra', 'Qureshi',
  'Venkatesh', 'Anand', 'Mishra', 'Goyal', 'Padmanabhan', 'Mittal', 'Chawla', 'Shukla', 'Bhardwaj', 'Nath'
];

const DEPARTMENTS = [
  'Computer Science',
  'Information Technology',
  'Electronics & Comm.',
  'AI & Data Science',
] as const;

const DEPT_SUBJECTS: Record<string, { code: string; subject: string; credits: number }[]> = {
  'Computer Science': [
    { code: 'CS701', subject: 'Advanced Algorithms', credits: 4 },
    { code: 'CS702', subject: 'Distributed Systems', credits: 4 },
    { code: 'CS703', subject: 'Machine Learning', credits: 4 },
    { code: 'CS704', subject: 'Cloud Computing', credits: 3 },
  ],
  'Information Technology': [
    { code: 'IT701', subject: 'Software Architecture', credits: 4 },
    { code: 'IT702', subject: 'Compiler Design', credits: 4 },
    { code: 'IT703', subject: 'Cyber Security', credits: 4 },
    { code: 'IT704', subject: 'Fullstack Systems', credits: 3 },
  ],
  'Electronics & Comm.': [
    { code: 'EC701', subject: 'VLSI Design', credits: 4 },
    { code: 'EC702', subject: 'Embedded Systems', credits: 4 },
    { code: 'EC703', subject: 'Digital Signal Proc.', credits: 4 },
    { code: 'EC704', subject: 'Wireless Comm.', credits: 3 },
  ],
  'AI & Data Science': [
    { code: 'AI701', subject: 'Deep Learning', credits: 4 },
    { code: 'AI702', subject: 'Natural Language Proc.', credits: 4 },
    { code: 'AI703', subject: 'Computer Vision', credits: 4 },
    { code: 'AI704', subject: 'Big Data Systems', credits: 3 },
  ],
};

const CERTIFICATIONS_POOL = [
  { title: 'AWS Solutions Architect Associate', issuer: 'Amazon Web Services' },
  { title: 'LeetCode 500+ Guardian Badge', issuer: 'LeetCode' },
  { title: 'Google Cloud Professional Architect', issuer: 'Google Cloud' },
  { title: 'Certified Kubernetes Administrator (CKA)', issuer: 'Linux Foundation' },
  { title: 'NPTEL Database Management (Elite+Gold)', issuer: 'IIT Kharagpur' },
  { title: 'TensorFlow Developer Certificate', issuer: 'Google' },
  { title: 'Meta Certified Front-End Developer', issuer: 'Meta' },
  { title: 'Oracle Certified Java Professional', issuer: 'Oracle' },
  { title: 'CompTIA Security+', issuer: 'CompTIA' },
  { title: 'DeepLearning.AI TensorFlow Specialization', issuer: 'Coursera' },
  { title: 'Full Stack Open Certification', issuer: 'University of Helsinki' },
  { title: 'Arm Embedded Developer', issuer: 'Arm Education' },
];

const MENTORS = [
  'Dr. Ramesh K. (HOD CS)',
  'Prof. Sneha Roy',
  'Prof. T. Murali',
  'Dr. V. Swaminathan',
  'Dr. Aruna Sen',
  'Prof. Rajesh Khanna',
  'Dr. Deepa Nair',
  'Prof. Sanjay Verma',
];

// Linear congruential generator for deterministic realistic data
function createRng(seed = 1234567) {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) % 4294967296;
    return s / 4294967296;
  };
}

export function generate100Students(): Student[] {
  const rng = createRng(428192);
  const students: Student[] = [];

  // Target distributions:
  // - Consistent High Achievers: ~18%
  // - High Academics - Low Placement ("The Bookworms"): ~22%
  // - High Placement - Academic/Attendance At-Risk ("Hidden Prodigies"): ~18%
  // - Silent Strugglers: ~16%
  // - Well-Rounded Core: ~26%

  for (let i = 1; i <= 100; i++) {
    const id = `STU-${String(i).padStart(3, '0')}`;
    const firstName = FIRST_NAMES[i - 1] || `Student${i}`;
    const lastName = LAST_NAMES[(i * 7) % LAST_NAMES.length];
    const name = `${firstName} ${lastName}`;
    const email = `${firstName.toLowerCase()}.${lastName.toLowerCase().slice(0, 3)}${i}@campus.edu`;
    const avatar = AVATARS[(i - 1) % AVATARS.length];

    const deptIndex = (i - 1) % 4;
    const department = DEPARTMENTS[deptIndex];
    const deptPrefix = department === 'Computer Science' ? 'CS' :
      department === 'Information Technology' ? 'IT' :
      department === 'Electronics & Comm.' ? 'EC' : 'AI';
    const rollNo = `21${deptPrefix}${100 + i}`;
    const semester = 7;
    const batch = '2022-2026';

    // Determine archetype based on index modulo 5 with variation
    const archetypeChoice = i % 5;
    let cgpa: number;
    let marksPct: number;
    let backlogs: number;
    let attendancePct: number;
    let attendanceTrend: 'improving' | 'declining' | 'stable';
    let lmsCompletion: number;
    let lmsLogins: number;
    let codingScore: number;
    let aptitudeScore: number;
    let mockTechRating: number;
    let mockHrRating: number;
    let resumeAtsScore: number;
    let certCount: number;
    let hackathons: number;
    let satisfaction: number;
    let facultyObs: string;
    let interventions: Intervention[] = [];

    if (archetypeChoice === 1) {
      // 1. Consistent High Achiever
      cgpa = +(8.8 + rng() * 0.95).toFixed(2);
      marksPct = Math.round(cgpa * 10 - 2 + rng() * 4);
      backlogs = 0;
      attendancePct = Math.round(88 + rng() * 10);
      attendanceTrend = rng() > 0.5 ? 'stable' : 'improving';
      lmsCompletion = Math.round(92 + rng() * 7);
      lmsLogins = Math.round(8 + rng() * 3);
      codingScore = Math.round(86 + rng() * 12);
      aptitudeScore = Math.round(84 + rng() * 14);
      mockTechRating = +(4.2 + rng() * 0.7).toFixed(1);
      mockHrRating = +(4.0 + rng() * 0.8).toFixed(1);
      resumeAtsScore = Math.round(88 + rng() * 10);
      certCount = Math.floor(2 + rng() * 2);
      hackathons = Math.floor(2 + rng() * 3);
      satisfaction = +(4.5 + rng() * 0.5).toFixed(1);
      facultyObs = 'Top-tier student with consistent analytical mastery and peer leadership.';
    } else if (archetypeChoice === 2) {
      // 2. High Academics - Low Placement ("The Bookworm")
      cgpa = +(8.4 + rng() * 1.0).toFixed(2);
      marksPct = Math.round(cgpa * 10 - 1 + rng() * 3);
      backlogs = 0;
      attendancePct = Math.round(86 + rng() * 10);
      attendanceTrend = 'stable';
      lmsCompletion = Math.round(90 + rng() * 8);
      lmsLogins = Math.round(7 + rng() * 3);
      codingScore = Math.round(44 + rng() * 16); // Below 60!
      aptitudeScore = Math.round(62 + rng() * 12);
      mockTechRating = +(2.2 + rng() * 0.6).toFixed(1);
      mockHrRating = +(3.2 + rng() * 0.6).toFixed(1);
      resumeAtsScore = Math.round(60 + rng() * 12);
      certCount = Math.floor(rng() * 2);
      hackathons = 0;
      satisfaction = +(3.2 + rng() * 0.8).toFixed(1);
      facultyObs = 'High theoretical grasp; struggles with live coding and whiteboard interviews.';
      interventions.push({
        id: `INT-${i}-01`,
        type: 'Placement Bootcamp',
        title: 'Intensive DSA & Whiteboard Coding Lab',
        assignedBy: 'Placement Cell',
        assignedDate: '2026-09-28',
        targetDate: '2026-10-30',
        status: 'in-progress',
        notes: 'Enrolled in 30-day algorithmic problem-solving sprint.',
      });
    } else if (archetypeChoice === 3) {
      // 3. High Placement - Academic / Attendance At-Risk ("Hidden Prodigy")
      cgpa = +(6.2 + rng() * 0.95).toFixed(2);
      marksPct = Math.round(60 + rng() * 10);
      backlogs = rng() > 0.4 ? 1 : 0;
      attendancePct = Math.round(62 + rng() * 11); // Often below 75%
      attendanceTrend = 'declining';
      lmsCompletion = Math.round(62 + rng() * 12);
      lmsLogins = Math.round(4 + rng() * 3);
      codingScore = Math.round(84 + rng() * 14); // Very high!
      aptitudeScore = Math.round(78 + rng() * 16);
      mockTechRating = +(4.3 + rng() * 0.6).toFixed(1);
      mockHrRating = +(3.6 + rng() * 0.6).toFixed(1);
      resumeAtsScore = Math.round(84 + rng() * 10);
      certCount = Math.floor(1 + rng() * 3);
      hackathons = Math.floor(3 + rng() * 3);
      satisfaction = +(3.0 + rng() * 0.6).toFixed(1);
      facultyObs = 'Exceptional builder and open-source hacker; skips theory lectures, exam detention risk.';
      interventions.push({
        id: `INT-${i}-02`,
        type: 'Attendance Counseling',
        title: 'Statutory 75% Attendance Undertaking',
        assignedBy: 'Dean of Student Affairs',
        assignedDate: '2026-10-02',
        targetDate: '2026-10-25',
        status: 'in-progress',
        notes: 'Signed undertaking to attend all remaining lectures to cross 75% barrier.',
      });
    } else if (archetypeChoice === 4) {
      // 4. Silent Struggler / Disengaged
      cgpa = +(5.4 + rng() * 1.1).toFixed(2);
      marksPct = Math.round(50 + rng() * 12);
      backlogs = Math.floor(1 + rng() * 2.5); // 1 to 3 backlogs
      attendancePct = Math.round(54 + rng() * 16); // Severe attendance drop
      attendanceTrend = 'declining';
      lmsCompletion = Math.round(40 + rng() * 22);
      lmsLogins = Math.round(2 + rng() * 2.5);
      codingScore = Math.round(34 + rng() * 20);
      aptitudeScore = Math.round(42 + rng() * 18);
      mockTechRating = +(1.8 + rng() * 0.6).toFixed(1);
      mockHrRating = +(2.4 + rng() * 0.6).toFixed(1);
      resumeAtsScore = Math.round(42 + rng() * 14);
      certCount = 0;
      hackathons = 0;
      satisfaction = +(2.0 + rng() * 0.8).toFixed(1);
      facultyObs = 'Withdrawn, falling behind on assignments and labs. Family consultation initiated.';
      interventions.push({
        id: `INT-${i}-03`,
        type: 'Remedial Tutoring',
        title: 'Core Subject Backlog Clearing Tutoring',
        assignedBy: 'HOD Academic Advisor',
        assignedDate: '2026-09-25',
        targetDate: '2026-11-15',
        status: 'in-progress',
        notes: 'Pairing with senior peer mentor for weekly concept review.',
      });
    } else {
      // 5. Well-Rounded Core
      cgpa = +(7.4 + rng() * 0.75).toFixed(2);
      marksPct = Math.round(72 + rng() * 8);
      backlogs = 0;
      attendancePct = Math.round(78 + rng() * 10);
      attendanceTrend = rng() > 0.4 ? 'stable' : 'improving';
      lmsCompletion = Math.round(78 + rng() * 12);
      lmsLogins = Math.round(6 + rng() * 2.5);
      codingScore = Math.round(68 + rng() * 12);
      aptitudeScore = Math.round(70 + rng() * 14);
      mockTechRating = +(3.4 + rng() * 0.7).toFixed(1);
      mockHrRating = +(3.8 + rng() * 0.7).toFixed(1);
      resumeAtsScore = Math.round(76 + rng() * 10);
      certCount = Math.floor(rng() * 2);
      hackathons = Math.floor(rng() * 2);
      satisfaction = +(4.0 + rng() * 0.5).toFixed(1);
      facultyObs = 'Reliable, active participant with steady coursework submissions.';
    }

    // Generate subject breakdown
    const courseList = DEPT_SUBJECTS[department] || DEPT_SUBJECTS['Computer Science'];
    const subjects: SubjectGrade[] = courseList.map((course) => {
      const baseScore = Math.round(cgpa * 10 - 5 + rng() * 10);
      const score = Math.max(35, Math.min(98, baseScore));
      let grade = 'B';
      if (score >= 90) grade = 'O';
      else if (score >= 80) grade = 'A+';
      else if (score >= 70) grade = 'A';
      else if (score >= 60) grade = 'B+';
      else if (score >= 50) grade = 'B';
      else grade = 'F';

      return {
        subject: course.subject,
        code: course.code,
        grade,
        score,
        credits: course.credits,
      };
    });

    // Attendance subject-wise
    const subjectWise = courseList.map((c) => ({
      subject: c.subject,
      pct: Math.max(45, Math.min(99, Math.round(attendancePct + (rng() * 10 - 5)))),
    }));

    // Weekly history (last 6 weeks)
    const weeklyHistory: number[] = [];
    let currentWeekAtt = attendancePct;
    for (let w = 0; w < 6; w++) {
      weeklyHistory.push(Math.max(40, Math.min(100, Math.round(currentWeekAtt))));
      if (attendanceTrend === 'declining') currentWeekAtt -= (rng() * 2);
      else if (attendanceTrend === 'improving') currentWeekAtt += (rng() * 2);
    }

    // Skills
    const skills: SkillRating[] = [
      { name: 'Data Structures & Algorithms', category: 'technical', currentScore: codingScore, targetScore: 80, verified: codingScore >= 75 },
      { name: 'Databases & SQL', category: 'technical', currentScore: Math.round(cgpa * 9), targetScore: 75, verified: true },
      { name: 'Web & API Development', category: 'technical', currentScore: Math.max(40, Math.min(95, codingScore + 5)), targetScore: 80, verified: codingScore >= 70 },
      { name: 'Communication', category: 'soft', currentScore: Math.round(mockHrRating * 20), targetScore: 80, verified: mockHrRating >= 4.0 },
      { name: 'Problem Solving', category: 'soft', currentScore: Math.round(aptitudeScore * 0.95), targetScore: 80, verified: aptitudeScore >= 75 },
    ];

    // Certifications
    const certifications: { title: string; issuer: string; date: string }[] = [];
    for (let c = 0; c < certCount; c++) {
      const pickedCert = CERTIFICATIONS_POOL[(i + c) % CERTIFICATIONS_POOL.length];
      certifications.push({
        title: pickedCert.title,
        issuer: pickedCert.issuer,
        date: `2024-0${Math.floor(1 + rng() * 8)}`,
      });
    }

    const rawStudent = {
      id,
      rollNo,
      name,
      email,
      avatar,
      department,
      semester,
      batch,
      cgpa,
      marksPct,
      backlogs,
      subjects,
      attendance: {
        overallPct: attendancePct,
        subjectWise,
        trend: attendanceTrend,
        weeklyHistory,
        classesAttended: Math.round((attendancePct / 100) * 180),
        totalClasses: 180,
      },
      lms: {
        weeklyLogins: lmsLogins,
        assignmentCompletionPct: lmsCompletion,
        quizzesAverage: Math.round(cgpa * 9.5),
        hoursSpentWeekly: Math.round(lmsLogins * 1.4),
        forumContributions: Math.floor(rng() * 15),
        lastActiveHoursAgo: Math.floor(1 + rng() * 48),
      },
      engagement: {
        eventsAttended: Math.floor(2 + rng() * 10),
        clubs: [{ name: `${department} Student Forum`, role: i % 10 === 0 ? 'Lead' : 'Member' }],
        hackathons,
        certifications,
        volunteeringHours: Math.floor(rng() * 30),
      },
      placement: {
        aptitudeScore,
        codingScore,
        mockTechRating,
        mockHrRating,
        resumeAtsScore,
        preferredRoles: ['Software Development Engineer', 'Full Stack Engineer'],
        status: (cgpa >= 8.5 && codingScore >= 85 ? 'offered' : 'unplaced') as any,
      },
      skills,
      feedback: {
        studentSatisfaction: satisfaction,
        facultyObservation: facultyObs,
        mentorName: MENTORS[i % MENTORS.length],
        lastMeetingDate: '2026-10-04',
      },
      interventions,
    };

    students.push(buildFullStudent(rawStudent));
  }

  return students;
}

export function buildFullStudent(raw: any): Student {
  const {
    academicScore,
    placementScore,
    attendanceScore,
    lmsScore,
    engagementScore,
    successScore,
  } = calculateSubScores(raw);

  const { academicRisk, placementRisk, overallRisk } = determineRisks(raw);
  const segment = determineSegment(raw, academicScore, placementScore);
  const explainableFactors = generateExplainableFactors(raw);

  return {
    ...raw,
    academicScore,
    placementReadinessScore: placementScore,
    successScore,
    academicRisk,
    placementRisk,
    overallRisk,
    segment,
    explainableFactors,
  };
}

// Exactly 100 students generated deterministically
export const INITIAL_STUDENTS: Student[] = generate100Students();
