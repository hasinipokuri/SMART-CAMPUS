export type RiskLevel = 'Low' | 'Moderate' | 'High' | 'Critical';

export type StudentSegment =
  | 'Consistent High Achievers'
  | 'High Academics - Low Placement'
  | 'High Placement - Academic/Attendance At-Risk'
  | 'Silent Strugglers / Disengaged'
  | 'Well-Rounded Core';

export interface SubjectGrade {
  subject: string;
  code: string;
  grade: string;
  score: number;
  credits: number;
}

export interface AttendanceRecord {
  overallPct: number;
  subjectWise: { subject: string; pct: number }[];
  trend: 'improving' | 'declining' | 'stable';
  weeklyHistory: number[]; // Last 6 weeks percentage
  classesAttended: number;
  totalClasses: number;
}

export interface LMSMetrics {
  weeklyLogins: number;
  assignmentCompletionPct: number;
  quizzesAverage: number;
  hoursSpentWeekly: number;
  forumContributions: number;
  lastActiveHoursAgo: number;
}

export interface EngagementMetrics {
  eventsAttended: number;
  clubs: { name: string; role: string }[];
  hackathons: number;
  certifications: { title: string; issuer: string; date: string }[];
  volunteeringHours: number;
}

export interface PlacementMetrics {
  aptitudeScore: number; // 0-100
  codingScore: number; // 0-100
  mockTechRating: number; // 1-5
  mockHrRating: number; // 1-5
  resumeAtsScore: number; // 0-100
  preferredRoles: string[];
  status: 'unplaced' | 'interviewing' | 'offered' | 'dream-offered';
}

export interface SkillRating {
  name: string;
  category: 'technical' | 'soft';
  currentScore: number; // 0-100
  targetScore: number; // 0-100
  verified: boolean;
}

export interface FeedbackData {
  studentSatisfaction: number; // 1-5
  facultyObservation: string;
  mentorName: string;
  lastMeetingDate: string;
}

export interface ScoreFactor {
  factor: string;
  category: 'Academic' | 'Placement' | 'Attendance' | 'LMS' | 'Engagement';
  impactPoints: number; // positive or negative
  valueDisplay: string;
  benchmark: string;
  insight: string;
  isPositive: boolean;
}

export interface Intervention {
  id: string;
  type: 'Academic Warning' | 'Remedial Tutoring' | 'Placement Bootcamp' | 'Attendance Counseling' | 'Faculty Mentorship' | 'Skill Workshop';
  title: string;
  assignedBy: string;
  assignedDate: string;
  targetDate: string;
  status: 'pending' | 'in-progress' | 'resolved';
  notes: string;
}

export interface Student {
  id: string;
  rollNo: string;
  name: string;
  email: string;
  avatar: string;
  department: 'Computer Science' | 'Information Technology' | 'Electronics & Comm.' | 'AI & Data Science';
  semester: number; // 4, 6, 8
  batch: string; // e.g. "2023-2027"

  // Raw data dimensions
  cgpa: number; // 0.0 - 10.0
  marksPct: number; // 0 - 100
  backlogs: number;
  subjects: SubjectGrade[];
  attendance: AttendanceRecord;
  lms: LMSMetrics;
  engagement: EngagementMetrics;
  placement: PlacementMetrics;
  skills: SkillRating[];
  feedback: FeedbackData;

  // Analytics & Decision Intelligence
  successScore: number; // 0 - 100
  academicScore: number; // 0 - 100
  placementReadinessScore: number; // 0 - 100
  academicRisk: RiskLevel;
  placementRisk: RiskLevel;
  overallRisk: RiskLevel;
  segment: StudentSegment;
  explainableFactors: ScoreFactor[];
  interventions: Intervention[];
}

export interface CohortStats {
  totalStudents: number;
  avgSuccessScore: number;
  avgCgpa: number;
  avgAttendance: number;
  avgCodingScore: number;
  avgAptitudeScore: number;
  avgLmsCompletion: number;
  academicAtRiskCount: number;
  academicAtRiskPct: number;
  placementAtRiskCount: number;
  placementAtRiskPct: number;
  criticalInterventionCount: number;
  segmentDistribution: Record<StudentSegment, number>;
  deptSummary: Record<string, { count: number; avgSuccess: number; atRiskPct: number }>;
}

export interface TargetJobRole {
  role: string;
  tier: 'Dream (25+ LPA)' | 'Tier-1 (10-25 LPA)' | 'Core Tech (5-10 LPA)';
  minCgpa: number;
  minCoding: number;
  minAptitude: number;
  skillsRequired: { name: string; minScore: number }[];
}
