import React from 'react';
import { X, BookOpen, CheckCircle2, AlertTriangle, Layers, Award, Target, ArrowRight } from 'lucide-react';
import { SCORE_WEIGHTS } from '../utils/analyticsEngine';

interface MethodologyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MethodologyModal: React.FC<MethodologyModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-500/20 rounded-lg border border-blue-400/30">
              <BookOpen className="w-6 h-6 text-blue-300" />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight">Student Success Score Methodology</h2>
              <p className="text-xs text-blue-200">Mathematical formulation, indicator rationale, and decision intelligence logic</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 md:p-8 max-h-[80vh] overflow-y-auto space-y-8 text-slate-700 text-sm">
          {/* Executive Summary */}
          <div className="p-4 rounded-xl bg-blue-50 border border-blue-100">
            <h3 className="font-semibold text-blue-950 text-base mb-1">Executive Rationale</h3>
            <p className="text-blue-900/90 leading-relaxed">
              Traditional college monitoring treats academic GPA, attendance records, LMS clickstreams, and placement readiness as separate silos. 
              The <strong>Smart Campus Success Score (0–100)</strong> unifies these disparate signals into a holistic, predictive indicator that detects 
              struggles weeks before examinations or recruitment drives occur.
            </p>
          </div>

          {/* Mathematical Formulation */}
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 mb-3">
              <Layers className="w-5 h-5 text-indigo-600" />
              1. The Composite Success Score Formula
            </h3>
            <div className="p-4 bg-slate-900 text-slate-100 rounded-xl font-mono text-xs md:text-sm overflow-x-auto shadow-inner">
              <span className="text-emerald-400">SuccessScore</span> = 
              (0.30 &times; <span className="text-blue-300">AcademicScore</span>) + 
              (0.25 &times; <span className="text-purple-300">PlacementScore</span>) + 
              (0.20 &times; <span className="text-amber-300">AttendanceScore</span>) + 
              (0.15 &times; <span className="text-cyan-300">LMSScore</span>) + 
              (0.10 &times; <span className="text-pink-300">EngagementScore</span>)
            </div>
          </div>

          {/* Detailed Indicator Breakdown */}
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 mb-3">
              <Target className="w-5 h-5 text-indigo-600" />
              2. Dimension Weights & Indicator Specifications
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Academic */}
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-slate-900">Academic Performance</span>
                  <span className="px-2 py-0.5 text-xs font-bold rounded-full bg-blue-100 text-blue-700">Weight: 30%</span>
                </div>
                <ul className="space-y-1.5 text-xs text-slate-600 list-disc list-inside">
                  <li><strong>CGPA Normalized:</strong> (CGPA / 10) &times; 80 points.</li>
                  <li><strong>Internal Marks:</strong> Periodic assessment consistency (20 points).</li>
                  <li><strong>Active Backlog Penalty:</strong> -12 points per standing backlog. Backlogs directly block 85% of campus recruitment eligibility.</li>
                </ul>
              </div>

              {/* Placement */}
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-slate-900">Placement & Employability</span>
                  <span className="px-2 py-0.5 text-xs font-bold rounded-full bg-purple-100 text-purple-700">Weight: 25%</span>
                </div>
                <ul className="space-y-1.5 text-xs text-slate-600 list-disc list-inside">
                  <li><strong>Coding Assessment:</strong> 40% weight (DSA, time complexity, test cases).</li>
                  <li><strong>Aptitude Score:</strong> 30% weight (Quantitative & logical reasoning).</li>
                  <li><strong>Mock Tech Interview:</strong> 20% weight (Whiteboarding & code walkthrough).</li>
                  <li><strong>Mock HR & ATS Resume:</strong> 10% weight (Soft skills & keyword relevance).</li>
                </ul>
              </div>

              {/* Attendance */}
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-slate-900">Attendance & Regularity</span>
                  <span className="px-2 py-0.5 text-xs font-bold rounded-full bg-amber-100 text-amber-700">Weight: 20%</span>
                </div>
                <ul className="space-y-1.5 text-xs text-slate-600 list-disc list-inside">
                  <li><strong>Statutory 75% Cliff:</strong> Full proportional score if &ge; 75%.</li>
                  <li><strong>Detention Cliff Penalty:</strong> For every percent below 75%, an accelerated penalty (0.8x drop) applies to simulate exam detention risk.</li>
                  <li><strong>Trend Penalty:</strong> Falling 4-week moving average triggers early warning.</li>
                </ul>
              </div>

              {/* LMS */}
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-slate-900">LMS & Digital Engagement</span>
                  <span className="px-2 py-0.5 text-xs font-bold rounded-full bg-cyan-100 text-cyan-700">Weight: 15%</span>
                </div>
                <ul className="space-y-1.5 text-xs text-slate-600 list-disc list-inside">
                  <li><strong>Assignment On-Time Completion:</strong> 70% weight (submission cadence).</li>
                  <li><strong>Weekly Active Logins:</strong> 30% weight (continuity & resource access).</li>
                  <li><strong>Leading Indicator:</strong> LMS drops often precede exam failures by 3 to 4 weeks.</li>
                </ul>
              </div>

              {/* Engagement */}
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 md:col-span-2">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-slate-900">Skills, Extracurriculars & Certifications</span>
                  <span className="px-2 py-0.5 text-xs font-bold rounded-full bg-pink-100 text-pink-700">Weight: 10%</span>
                </div>
                <p className="text-xs text-slate-600">
                  Combines verified industry certifications (AWS, Google Cloud, CKA, NPTEL Elite), competitive hackathon wins, 
                  college club leadership, and assessed soft skills (Communication, Teamwork, Problem Solving).
                </p>
              </div>
            </div>
          </div>

          {/* Dual Risk Identification Engine */}
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 mb-3">
              <AlertTriangle className="w-5 h-5 text-amber-500" />
              3. Dual-Risk Identification Architecture
            </h3>
            <p className="text-xs text-slate-600 mb-3">
              Students do not fail uniformly. A student can have a 9.0 CGPA but still fail placement rounds, or have 95/100 coding skills but get detained due to 60% attendance.
              We decouple risk into two autonomous engines:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl border border-rose-200 bg-rose-50/40">
                <h4 className="font-bold text-rose-900 text-xs uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-rose-600"></span>
                  Academic Risk Triggers
                </h4>
                <ul className="space-y-1 text-xs text-rose-950">
                  <li>&bull; <strong>Critical:</strong> Active backlogs &ge; 2 OR Attendance &lt; 65% OR CGPA &lt; 5.8</li>
                  <li>&bull; <strong>High:</strong> Active backlogs = 1 OR Attendance &lt; 75% OR CGPA &lt; 6.8</li>
                  <li>&bull; <strong>Moderate:</strong> Attendance 75–80% OR LMS Completion &lt; 70%</li>
                </ul>
              </div>

              <div className="p-4 rounded-xl border border-purple-200 bg-purple-50/40">
                <h4 className="font-bold text-purple-900 text-xs uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-purple-600"></span>
                  Placement Risk Triggers
                </h4>
                <ul className="space-y-1 text-xs text-purple-950">
                  <li>&bull; <strong>Critical:</strong> Coding Score &lt; 45 OR Aptitude &lt; 45 OR (Sem &ge; 6 &amp; Backlog &gt; 0)</li>
                  <li>&bull; <strong>High:</strong> Coding Score &lt; 60 OR Aptitude &lt; 55 OR Mock Tech &lt; 2.5/5.0</li>
                  <li>&bull; <strong>Moderate:</strong> Coding Score &lt; 72 OR Mock Tech &lt; 3.5 OR Resume &lt; 65</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Student Segmentation Matrix */}
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 mb-3">
              <Award className="w-5 h-5 text-emerald-600" />
              4. 4-Quadrant Behavioral Segmentation (Bonus Feature)
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-lg border border-indigo-200 bg-indigo-50/50">
                <p className="font-bold text-indigo-900">1. Consistent High Achievers (Top Right)</p>
                <p className="text-indigo-800/80">CGPA &ge; 8.3 &amp; Coding &ge; 75. Prime candidates for Tier-1 / Dream roles (25+ LPA).</p>
              </div>
              <div className="p-3 rounded-lg border border-amber-200 bg-amber-50/50">
                <p className="font-bold text-amber-900">2. The Bookworms (Bottom Right)</p>
                <p className="text-amber-800/80">CGPA &ge; 7.8 but Coding &lt; 64. High theory, low whiteboard confidence. Need mock bootcamps.</p>
              </div>
              <div className="p-3 rounded-lg border border-cyan-200 bg-cyan-50/50">
                <p className="font-bold text-cyan-900">3. Hidden Prodigies (Top Left)</p>
                <p className="text-cyan-800/80">Coding &ge; 76 but Attendance &lt; 75% or CGPA &lt; 7.2. Brilliant developers risking detention.</p>
              </div>
              <div className="p-3 rounded-lg border border-rose-200 bg-rose-50/50">
                <p className="font-bold text-rose-900">4. Silent Strugglers (Bottom Left)</p>
                <p className="text-rose-800/80">Low LMS, low attendance, borderline CGPA. Highest dropout &amp; burnout vulnerability.</p>
              </div>
            </div>
          </div>

          {/* Explainable AI Score Drivers */}
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2 mb-2">
              <CheckCircle2 className="w-5 h-5 text-blue-600" />
              5. Explainable Score Architecture (Bonus Feature)
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Instead of an opaque black-box number, every student’s score is computed with transparent 
              <strong> feature contribution attribution (SHAP-inspired waterfall)</strong>. Students and faculty can inspect 
              the baseline score (50.0 pts) and see exactly which indicators provided positive lift (e.g. +14.2 pts for CGPA 9.2) 
              or negative drag (e.g. -12.0 pts for attendance 68%), giving faculty a clear roadmap for interventions.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-50 border-t border-slate-100">
          <span className="text-xs text-slate-500 font-medium">Smart Campus Decision Intelligence Engine v3.8</span>
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
          >
            Close Documentation
          </button>
        </div>
      </div>
    </div>
  );
};
