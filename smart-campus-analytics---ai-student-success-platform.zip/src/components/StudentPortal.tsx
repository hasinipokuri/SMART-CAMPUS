import React, { useState } from 'react';
import {
  Award,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  Target,
  Sparkles,
  BookOpen,
  Calendar,
  Briefcase,
  ChevronRight,
  ArrowUpRight,
  ArrowDownRight,
  Calculator,
  UserCheck,
  Zap,
} from 'lucide-react';
import { Student } from '../types/student';
import { TARGET_JOB_ROLES } from '../utils/analyticsEngine';

interface StudentPortalProps {
  students: Student[];
  currentStudentId: string;
  onSelectStudentId: (id: string) => void;
  onOpenMethodology: () => void;
}

export const StudentPortal: React.FC<StudentPortalProps> = ({
  students,
  currentStudentId,
  onSelectStudentId,
  onOpenMethodology,
}) => {
  const student = students.find((s) => s.id === currentStudentId) || students[0];

  const [selectedRoleIndex, setSelectedRoleIndex] = useState(0);
  const selectedRole = TARGET_JOB_ROLES[selectedRoleIndex];

  // What-if attendance calculator state
  const [upcomingClassesToAttend, setUpcomingClassesToAttend] = useState(15);
  const currentAttended = student.attendance.classesAttended;
  const currentTotal = student.attendance.totalClasses;
  const projectedAttended = currentAttended + upcomingClassesToAttend;
  const projectedTotal = currentTotal + upcomingClassesToAttend;
  const projectedAttendancePct = Math.min(100, Math.round((projectedAttended / projectedTotal) * 100));

  // AI Advice state
  const [loadingAi, setLoadingAi] = useState(false);
  const [aiAdvice, setAiAdvice] = useState<any>(null);

  const fetchStudentAiAdvice = async () => {
    setLoadingAi(true);
    try {
      const res = await fetch('/api/ai/student-advice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ student, targetCompanyTier: selectedRole.role }),
      });
      const data = await res.json();
      setAiAdvice(data.advice);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingAi(false);
    }
  };

  // Eligibility check against selected target role
  const isCgpaEligible = student.cgpa >= selectedRole.minCgpa;
  const isBacklogEligible = student.backlogs === 0;
  const isCodingEligible = student.placement.codingScore >= selectedRole.minCoding;
  const isAptitudeEligible = student.placement.aptitudeScore >= selectedRole.minAptitude;
  const isFullyEligible = isCgpaEligible && isBacklogEligible && isCodingEligible && isAptitudeEligible;

  return (
    <div className="space-y-6">
      {/* Student View Banner & Switcher */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <img
              src={student.avatar}
              alt={student.name}
              className="w-16 h-16 rounded-2xl object-cover border-2 border-white/20 shadow-lg"
            />
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-indigo-500/30 text-indigo-200 border border-indigo-400/30">
                  Student Portal &bull; My Success Hub
                </span>
                <span className="text-xs px-2 py-0.5 rounded bg-white/10 text-slate-300 font-mono">
                  {student.rollNo}
                </span>
              </div>
              <h1 className="text-2xl font-black mt-1">{student.name}</h1>
              <p className="text-xs text-blue-200">
                {student.department} &bull; Semester {student.semester} &bull; Mentor: {student.feedback.mentorName}
              </p>
            </div>
          </div>

          {/* Quick Profile Switcher (allows demoing different student archetypes) */}
          <div className="bg-white/10 p-3 rounded-xl border border-white/15 backdrop-blur-sm">
            <label className="block text-[11px] font-bold text-blue-200 mb-1 flex items-center gap-1.5">
              <UserCheck className="w-3.5 h-3.5 text-blue-300" /> Switch Student Persona (Demo View):
            </label>
            <select
              value={student.id}
              onChange={(e) => onSelectStudentId(e.target.value)}
              className="w-full text-xs py-1.5 px-3 rounded-lg bg-slate-900 text-white border border-white/20 focus:outline-none max-w-sm"
            >
              {[
                'Consistent High Achievers',
                'High Academics - Low Placement',
                'High Placement - Academic/Attendance At-Risk',
                'Silent Strugglers / Disengaged',
                'Well-Rounded Core',
              ].map((segmentName) => {
                const segmentStudents = students.filter((s) => s.segment === segmentName);
                if (segmentStudents.length === 0) return null;
                return (
                  <optgroup key={segmentName} label={`${segmentName} (${segmentStudents.length})`}>
                    {segmentStudents.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.rollNo} &bull; CGPA: {s.cgpa} &bull; Att: {s.attendance.overallPct}%)
                      </option>
                    ))}
                  </optgroup>
                );
              })}
            </select>
          </div>
        </div>
      </div>

      {/* Top Success Score & Standing Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Success Score Card */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">My Success Score</span>
              <button
                onClick={onOpenMethodology}
                className="text-[11px] font-semibold text-indigo-600 hover:text-indigo-800 underline"
              >
                How it&apos;s calculated
              </button>
            </div>
            <div className="flex items-baseline gap-2 mt-2">
              <span className="text-4xl font-black text-slate-900">{student.successScore}</span>
              <span className="text-sm text-slate-400 font-medium">/ 100</span>
            </div>
            <span className={`inline-block mt-2 px-2.5 py-0.5 rounded-full text-xs font-bold ${
              student.successScore >= 80 ? 'bg-emerald-100 text-emerald-800' :
              student.successScore >= 65 ? 'bg-blue-100 text-blue-800' :
              student.successScore >= 50 ? 'bg-amber-100 text-amber-800' :
              'bg-rose-100 text-rose-800'
            }`}>
              {student.segment}
            </span>
          </div>
          <p className="text-[11px] text-slate-500 mt-3 pt-3 border-t border-slate-100">
            {student.successScore >= 75 ? 'Dean\'s Honor standing &bull; On track for Day-1 placements' : 'Targeted improvements needed in attendance or coding'}
          </p>
        </div>

        {/* Academic Health */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Academic Standing</span>
              <BookOpen className="w-4 h-4 text-indigo-600" />
            </div>
            <div className="flex items-baseline gap-2 mt-2">
              <span className="text-3xl font-black text-slate-900">{student.cgpa.toFixed(2)}</span>
              <span className="text-xs text-slate-400">CGPA</span>
            </div>
            <div className="mt-2 text-xs">
              Backlogs: <strong className={student.backlogs > 0 ? 'text-rose-600' : 'text-emerald-600'}>{student.backlogs}</strong> &bull; 
              Marks: <strong className="text-slate-800">{student.marksPct}%</strong>
            </div>
          </div>
          <p className="text-[11px] text-slate-500 mt-3 pt-3 border-t border-slate-100">
            Risk status: <strong className={student.academicRisk === 'Critical' || student.academicRisk === 'High' ? 'text-rose-600' : 'text-emerald-600'}>{student.academicRisk}</strong>
          </p>
        </div>

        {/* Attendance Health */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Attendance</span>
              <Calendar className="w-4 h-4 text-amber-600" />
            </div>
            <div className="flex items-baseline gap-2 mt-2">
              <span className={`text-3xl font-black ${student.attendance.overallPct < 75 ? 'text-rose-600' : 'text-emerald-600'}`}>
                {student.attendance.overallPct}%
              </span>
              <span className="text-xs text-slate-400">overall</span>
            </div>
            <div className="mt-2 text-xs text-slate-600">
              Classes: <strong>{student.attendance.classesAttended} / {student.attendance.totalClasses}</strong>
            </div>
          </div>
          <p className="text-[11px] text-slate-500 mt-3 pt-3 border-t border-slate-100">
            {student.attendance.overallPct >= 75 ? (
              <span className="text-emerald-700 font-medium flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Exam hall ticket safe (&ge;75%)
              </span>
            ) : (
              <span className="text-rose-700 font-bold flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" /> Hall ticket blocked (&lt;75%)
              </span>
            )}
          </p>
        </div>

        {/* Placement Readiness */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Placement Score</span>
              <Briefcase className="w-4 h-4 text-purple-600" />
            </div>
            <div className="flex items-baseline gap-2 mt-2">
              <span className="text-3xl font-black text-slate-900">{student.placement.codingScore}</span>
              <span className="text-xs text-slate-400">Coding / 100</span>
            </div>
            <div className="mt-2 text-xs text-slate-600">
              Aptitude: <strong>{student.placement.aptitudeScore}</strong> &bull; Mock Tech: <strong>{student.placement.mockTechRating}/5</strong>
            </div>
          </div>
          <p className="text-[11px] text-slate-500 mt-3 pt-3 border-t border-slate-100">
            Placement Risk: <strong className={student.placementRisk === 'Critical' || student.placementRisk === 'High' ? 'text-rose-600' : 'text-emerald-600'}>{student.placementRisk}</strong>
          </p>
        </div>
      </div>

      {/* SECTION: PLACEMENT & SKILLS REQUIREMENTS (CORE REQUIREMENT FROM USER) */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Target className="w-5 h-5 text-indigo-600" />
              Placement Readiness &amp; Required Industry Skills Matrix
            </h2>
            <p className="text-xs text-slate-500">
              Compare your current technical competencies against benchmark company cutoffs and job tier profiles.
            </p>
          </div>

          {/* Role selector dropdown */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-600">Target Role:</span>
            <select
              value={selectedRoleIndex}
              onChange={(e) => setSelectedRoleIndex(Number(e.target.value))}
              className="text-xs py-2 px-3 rounded-xl border border-slate-300 bg-slate-50 font-semibold text-slate-800"
            >
              {TARGET_JOB_ROLES.map((role, idx) => (
                <option key={idx} value={idx}>
                  {role.role} &bull; {role.tier}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Eligibility Check Banners */}
        <div className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs ${
          isFullyEligible ? 'bg-emerald-50 border-emerald-200' : 'bg-amber-50 border-amber-200'
        }`}>
          <div>
            <span className={`font-bold text-sm block ${isFullyEligible ? 'text-emerald-950' : 'text-amber-950'}`}>
              {isFullyEligible ? 'Eligible for ' + selectedRole.role : 'Gaps Detected for ' + selectedRole.role}
            </span>
            <p className={`text-[11px] mt-0.5 ${isFullyEligible ? 'text-emerald-800' : 'text-amber-800'}`}>
              Tier requirement: Minimum CGPA &ge; {selectedRole.minCgpa}, 0 Backlogs, Coding &ge; {selectedRole.minCoding}, Aptitude &ge; {selectedRole.minAptitude}.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0 text-xs">
            <span className={`px-2.5 py-1 rounded-lg font-bold ${isCgpaEligible ? 'bg-emerald-200/80 text-emerald-900' : 'bg-rose-200/80 text-rose-900'}`}>
              CGPA: {student.cgpa.toFixed(2)} / {selectedRole.minCgpa}
            </span>
            <span className={`px-2.5 py-1 rounded-lg font-bold ${isBacklogEligible ? 'bg-emerald-200/80 text-emerald-900' : 'bg-rose-200/80 text-rose-900'}`}>
              Backlogs: {student.backlogs} (0 req.)
            </span>
            <span className={`px-2.5 py-1 rounded-lg font-bold ${isCodingEligible ? 'bg-emerald-200/80 text-emerald-900' : 'bg-rose-200/80 text-rose-900'}`}>
              Coding: {student.placement.codingScore} / {selectedRole.minCoding}
            </span>
          </div>
        </div>

        {/* Required Skills vs Current Student Competency */}
        <div className="space-y-4">
          <h3 className="font-bold text-slate-900 text-sm">
            Core Skill Gap Analysis for {selectedRole.role}
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {selectedRole.skillsRequired.map((reqSkill, i) => {
              const matchedStudentSkill = student.skills.find(
                (s) => s.name.toLowerCase() === reqSkill.name.toLowerCase()
              );
              const currentScore = matchedStudentSkill ? matchedStudentSkill.currentScore : 55;
              const gap = reqSkill.minScore - currentScore;
              const isReady = gap <= 0;

              return (
                <div key={i} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-900">{reqSkill.name}</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      isReady ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                    }`}>
                      {isReady ? 'Ready' : `Gap: -${gap} pts`}
                    </span>
                  </div>

                  {/* Dual comparison bar */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px] text-slate-500 font-mono">
                      <span>Your Score: <strong className="text-slate-800">{currentScore}/100</strong></span>
                      <span>Target: {reqSkill.minScore}/100</span>
                    </div>
                    <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden relative">
                      <div
                        style={{ width: `${currentScore}%` }}
                        className={`h-full rounded-full transition-all ${
                          isReady ? 'bg-emerald-500' : 'bg-amber-500'
                        }`}
                      ></div>
                      {/* Target threshold marker */}
                      <div
                        style={{ left: `${reqSkill.minScore}%` }}
                        className="absolute top-0 bottom-0 w-0.5 bg-slate-900"
                        title={`Target Cutoff: ${reqSkill.minScore}`}
                      ></div>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-600">
                    {isReady
                      ? 'You exceed benchmark requirements for this role. Maintain practice!'
                      : `Recommended action: Solve 15 targeted practice modules in ${reqSkill.name} to close the ${gap}-point gap.`}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* TWO COLUMN GRID: WHAT-IF ATTENDANCE CALCULATOR + EXPLAINABLE SCORE DRIVERS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* INTERACTIVE ATTENDANCE "WHAT-IF" SIMULATOR */}
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
              <Calculator className="w-5 h-5 text-indigo-600" />
              Attendance Recovery &ldquo;What-If&rdquo; Simulator
            </h3>
            <span className="text-xs px-2.5 py-0.5 rounded-full font-bold bg-amber-100 text-amber-800">
              Statutory 75% Rule
            </span>
          </div>
          <p className="text-xs text-slate-500">
            See how attending upcoming classes will lift your attendance percentage and secure your exam hall ticket.
          </p>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-4">
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                <span>Upcoming Classes I Will Attend:</span>
                <span className="text-indigo-600 font-bold">{upcomingClassesToAttend} Classes</span>
              </div>
              <input
                type="range"
                min="0"
                max="40"
                step="1"
                value={upcomingClassesToAttend}
                onChange={(e) => setUpcomingClassesToAttend(Number(e.target.value))}
                className="w-full accent-indigo-600 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 mt-1">
                <span>0 Classes</span>
                <span>20 Classes</span>
                <span>40 Classes</span>
              </div>
            </div>

            {/* Projected result */}
            <div className="grid grid-cols-2 gap-3 pt-2 text-center">
              <div className="p-3 bg-white rounded-xl border border-slate-200">
                <span className="text-[11px] text-slate-500 block">Current Attendance</span>
                <span className="text-2xl font-black text-slate-900 mt-0.5 block">{student.attendance.overallPct}%</span>
                <span className="text-[10px] text-slate-400">({currentAttended} / {currentTotal} hrs)</span>
              </div>

              <div className={`p-3 rounded-xl border ${projectedAttendancePct >= 75 ? 'bg-emerald-50 border-emerald-200' : 'bg-rose-50 border-rose-200'}`}>
                <span className="text-[11px] text-slate-600 block">Projected Attendance</span>
                <span className={`text-2xl font-black mt-0.5 block ${projectedAttendancePct >= 75 ? 'text-emerald-700' : 'text-rose-700'}`}>
                  {projectedAttendancePct}%
                </span>
                <span className="text-[10px] text-slate-500">({projectedAttended} / {projectedTotal} hrs)</span>
              </div>
            </div>

            <div className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
              projectedAttendancePct >= 75 ? 'bg-emerald-100/70 text-emerald-900 font-medium' : 'bg-rose-100/70 text-rose-900 font-medium'
            }`}>
              {projectedAttendancePct >= 75 ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                  <span>Safe Zone! You will clear the mandatory 75% exam hall ticket eligibility cutoff.</span>
                </>
              ) : (
                <>
                  <AlertTriangle className="w-4 h-4 text-rose-700 shrink-0" />
                  <span>Still below 75%! You need to attend at least {Math.max(1, Math.ceil((0.75 * currentTotal - currentAttended) / 0.25))} more classes consecutively.</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* EXPLAINABLE SCORE: WHAT'S BOOSTING VS HOLDING BACK */}
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-indigo-600" />
              What Drives Your Success Score?
            </h3>
            <span className="text-xs text-slate-400 font-mono">Baseline: 50.0 pts</span>
          </div>
          <p className="text-xs text-slate-500">
            Transparent breakdown of your strengths and bottlenecks based on campus metrics.
          </p>

          <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
            {student.explainableFactors.map((factor, idx) => (
              <div
                key={idx}
                className={`p-3 rounded-xl border flex items-center justify-between text-xs ${
                  factor.isPositive ? 'bg-emerald-50/50 border-emerald-200' : 'bg-rose-50/50 border-rose-200'
                }`}
              >
                <div className="flex items-center gap-2">
                  <div className={`p-1 rounded-md ${factor.isPositive ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                    {factor.isPositive ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
                  </div>
                  <div>
                    <span className="font-bold text-slate-900 block">{factor.factor}</span>
                    <span className={`text-[11px] ${factor.isPositive ? 'text-emerald-800' : 'text-rose-800'}`}>
                      {factor.valueDisplay} &bull; {factor.insight}
                    </span>
                  </div>
                </div>

                <span className={`font-mono font-bold text-xs px-2 py-0.5 rounded ${
                  factor.isPositive ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                }`}>
                  {factor.impactPoints >= 0 ? `+${factor.impactPoints}` : factor.impactPoints} pts
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* AI PERSONAL COACH ROADMAP (GEMINI 3.8 FLASH) */}
      <div className="p-6 rounded-2xl bg-gradient-to-br from-indigo-50 via-blue-50 to-purple-50 border border-indigo-200 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-indigo-600 text-white">
              AI Student Coach
            </span>
            <h3 className="text-lg font-bold text-indigo-950 mt-1 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-600" />
              Your Personalized 30-Day Growth Sprint
            </h3>
            <p className="text-xs text-indigo-900/80">
              Generated by Gemini 3.8 Flash based on your exact grades, attendance patterns, and dream role targets.
            </p>
          </div>

          <button
            onClick={fetchStudentAiAdvice}
            disabled={loadingAi}
            className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-md flex items-center gap-1.5 transition-colors shrink-0 disabled:opacity-50"
          >
            {loadingAi ? 'Formulating Advice...' : 'Generate My 30-Day Plan'}
          </button>
        </div>

        {aiAdvice ? (
          <div className="space-y-4 text-xs animate-in fade-in duration-150">
            <div className="p-4 bg-white/95 rounded-xl border border-indigo-200">
              <span className="font-bold text-indigo-900 block uppercase tracking-wide text-[11px] mb-1">Coach Diagnosis</span>
              <p className="text-slate-700 leading-relaxed">{aiAdvice.summary}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="p-4 bg-white/95 rounded-xl border border-blue-200">
                <span className="font-bold text-blue-900 block uppercase tracking-wide text-[11px] mb-2 flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4 text-blue-600" /> Academic &amp; Attendance Sprint
                </span>
                <ul className="space-y-1.5 text-slate-700">
                  {aiAdvice.academicActionPlan?.map((item: string, i: number) => (
                    <li key={i} className="flex items-start gap-1.5">
                      <span className="font-bold text-blue-600">&bull;</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-4 bg-white/95 rounded-xl border border-purple-200">
                <span className="font-bold text-purple-900 block uppercase tracking-wide text-[11px] mb-2 flex items-center gap-1.5">
                  <Briefcase className="w-4 h-4 text-purple-600" /> Placement Coding Priorities
                </span>
                <ul className="space-y-1.5 text-slate-700">
                  {aiAdvice.placementActionPlan?.map((item: string, i: number) => (
                    <li key={i} className="flex items-start gap-1.5">
                      <span className="font-bold text-purple-600">&bull;</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {aiAdvice.encouragementQuote && (
              <p className="text-center italic text-indigo-900/80 text-xs pt-1">
                &ldquo;{aiAdvice.encouragementQuote}&rdquo;
              </p>
            )}
          </div>
        ) : (
          <div className="p-8 text-center bg-white/70 rounded-xl border border-dashed border-indigo-200">
            <Sparkles className="w-6 h-6 text-indigo-500 mx-auto mb-2" />
            <p className="text-xs font-semibold text-indigo-950">
              Click &ldquo;Generate My 30-Day Plan&rdquo; to analyze your blockers and create a tailored schedule.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
