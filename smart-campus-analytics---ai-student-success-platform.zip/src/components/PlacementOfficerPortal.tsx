import React, { useState } from 'react';
import {
  Briefcase,
  Sliders,
  Download,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Award,
  Layers,
  Search,
  Zap,
  Users,
} from 'lucide-react';
import { Student } from '../types/student';

interface PlacementOfficerPortalProps {
  students: Student[];
  onSelectStudent: (student: Student) => void;
  onBatchIntervention: (type: string, title: string, studentIds: string[]) => void;
}

export const PlacementOfficerPortal: React.FC<PlacementOfficerPortalProps> = ({
  students,
  onSelectStudent,
  onBatchIntervention,
}) => {
  // Company criteria filter simulator
  const [minCgpa, setMinCgpa] = useState<number>(7.0);
  const [maxBacklogs, setMaxBacklogs] = useState<number>(0);
  const [minCoding, setMinCoding] = useState<number>(65);
  const [minAptitude, setMinAptitude] = useState<number>(60);
  const [selectedDept, setSelectedDept] = useState<string>('all');
  const [companyName, setCompanyName] = useState<string>('Google / Microsoft / Amazon');

  // Filter students based on corporate drive criteria
  const eligibleStudents = students.filter((s) => {
    if (s.cgpa < minCgpa) return false;
    if (s.backlogs > maxBacklogs) return false;
    if (s.placement.codingScore < minCoding) return false;
    if (s.placement.aptitudeScore < minAptitude) return false;
    if (selectedDept !== 'all' && s.department !== selectedDept) return false;
    return true;
  });

  const disqualifiedStudents = students.filter(
    (s) => !eligibleStudents.some((e) => e.id === s.id)
  );

  // Export shortlist as CSV
  const handleExportShortlistCsv = () => {
    const headers = ['Roll No', 'Name', 'Department', 'CGPA', 'Backlogs', 'Attendance %', 'Coding Score', 'Aptitude Score', 'Success Score'];
    const rows = eligibleStudents.map((s) => [
      s.rollNo,
      s.name,
      s.department,
      s.cgpa.toFixed(2),
      s.backlogs,
      s.attendance.overallPct,
      s.placement.codingScore,
      s.placement.aptitudeScore,
      s.successScore,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Placement_Shortlist_${companyName.replace(/\s+/g, '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Skill benchmarks across cohort
  const avgCoding = Math.round(students.reduce((acc, s) => acc + s.placement.codingScore, 0) / students.length);
  const avgAptitude = Math.round(students.reduce((acc, s) => acc + s.placement.aptitudeScore, 0) / students.length);
  const avgMockTech = +(students.reduce((acc, s) => acc + s.placement.mockTechRating, 0) / students.length).toFixed(1);
  const avgResumeAts = Math.round(students.reduce((acc, s) => acc + s.placement.resumeAtsScore, 0) / students.length);

  // Group into tiers
  const dreamReady = students.filter((s) => s.cgpa >= 8.2 && s.placement.codingScore >= 80 && s.backlogs === 0);
  const tier1Ready = students.filter((s) => s.cgpa >= 7.2 && s.placement.codingScore >= 70 && s.backlogs === 0 && !dreamReady.includes(s));
  const coreReady = students.filter((s) => s.cgpa >= 6.5 && s.placement.codingScore >= 55 && !dreamReady.includes(s) && !tier1Ready.includes(s));
  const atRiskPlacement = students.filter((s) => s.placementRisk === 'High' || s.placementRisk === 'Critical');

  return (
    <div className="space-y-6">
      {/* Placement Header Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-purple-950 via-indigo-900 to-slate-900 text-white shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-purple-500/30 text-purple-200 border border-purple-400/30">
                Career &amp; Placement Cell
              </span>
              <span className="text-xs text-purple-200 font-mono">Academic Year 2026-27</span>
            </div>
            <h1 className="text-2xl font-black">Campus Placement &amp; Employability Hub</h1>
            <p className="text-xs text-slate-300 mt-1">
              Real-time drive simulation, skill deficit tracking, and automated candidate shortlisting.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                const weakCodingStudentIds = students.filter((s) => s.placement.codingScore < 60).map((s) => s.id);
                onBatchIntervention('Placement Bootcamp', 'Intensive 30-Day DSA Accelerator', weakCodingStudentIds);
              }}
              className="px-3.5 py-2 text-xs font-bold rounded-xl bg-purple-600 hover:bg-purple-500 text-white shadow-md flex items-center gap-1.5 transition-colors"
            >
              <Zap className="w-3.5 h-3.5" /> Bootcamp for Weak Coders ({students.filter((s) => s.placement.codingScore < 60).length})
            </button>
          </div>
        </div>
      </div>

      {/* Placement Readiness Funnel */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500">
            <span>Dream Tier (25+ LPA)</span>
            <Award className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-3xl font-black text-emerald-600 mt-2">{dreamReady.length}</div>
          <p className="text-[11px] text-slate-500 mt-1">
            {Math.round((dreamReady.length / students.length) * 100)}% of cohort &bull; CGPA &ge; 8.2 &amp; Coding &ge; 80
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500">
            <span>Tier-1 Tech (10-25 LPA)</span>
            <CheckCircle2 className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-3xl font-black text-indigo-600 mt-2">{tier1Ready.length}</div>
          <p className="text-[11px] text-slate-500 mt-1">
            {Math.round((tier1Ready.length / students.length) * 100)}% of cohort &bull; CGPA &ge; 7.2 &amp; Coding &ge; 70
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500">
            <span>Mass Core (5-10 LPA)</span>
            <Layers className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-3xl font-black text-blue-600 mt-2">{coreReady.length}</div>
          <p className="text-[11px] text-slate-500 mt-1">
            {Math.round((coreReady.length / students.length) * 100)}% of cohort &bull; Coding &ge; 55
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-rose-200 shadow-sm bg-rose-50/30">
          <div className="flex items-center justify-between text-xs font-bold text-rose-700">
            <span>Placement At-Risk</span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-3xl font-black text-rose-700 mt-2">{atRiskPlacement.length}</div>
          <p className="text-[11px] text-rose-800 mt-1">
            {Math.round((atRiskPlacement.length / students.length) * 100)}% need urgent intervention
          </p>
        </div>
      </div>

      {/* INTERACTIVE COMPANY CRITERIA SIMULATOR */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Sliders className="w-5 h-5 text-indigo-600" />
              Company Recruitment Eligibility Simulator
            </h2>
            <p className="text-xs text-slate-500">
              Adjust cutoff parameters to instantly calculate qualified candidates and export recruitment rosters.
            </p>
          </div>

          <button
            onClick={handleExportShortlistCsv}
            disabled={eligibleStudents.length === 0}
            className="px-4 py-2 text-xs font-bold rounded-xl bg-slate-900 hover:bg-slate-800 text-white shadow-sm flex items-center gap-2 transition-colors disabled:opacity-40"
          >
            <Download className="w-4 h-4" /> Export Shortlist ({eligibleStudents.length} Students)
          </button>
        </div>

        {/* Sliders Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs">
          {/* Target Company Name */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Company / Drive Profile</label>
            <input
              type="text"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white"
            />
          </div>

          {/* Min CGPA */}
          <div>
            <div className="flex justify-between font-semibold text-slate-700 mb-1">
              <span>Min CGPA:</span>
              <span className="text-indigo-600 font-bold">{minCgpa.toFixed(1)}</span>
            </div>
            <input
              type="range"
              min="5.0"
              max="9.0"
              step="0.2"
              value={minCgpa}
              onChange={(e) => setMinCgpa(parseFloat(e.target.value))}
              className="w-full accent-indigo-600 cursor-pointer"
            />
          </div>

          {/* Max Backlogs */}
          <div>
            <div className="flex justify-between font-semibold text-slate-700 mb-1">
              <span>Max Backlogs Allowed:</span>
              <span className="text-indigo-600 font-bold">{maxBacklogs}</span>
            </div>
            <select
              value={maxBacklogs}
              onChange={(e) => setMaxBacklogs(parseInt(e.target.value, 10))}
              className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white"
            >
              <option value={0}>0 Backlogs (Strict)</option>
              <option value={1}>Max 1 Backlog</option>
              <option value={2}>Max 2 Backlogs</option>
            </select>
          </div>

          {/* Min Coding Score */}
          <div>
            <div className="flex justify-between font-semibold text-slate-700 mb-1">
              <span>Min Coding Score:</span>
              <span className="text-indigo-600 font-bold">{minCoding} / 100</span>
            </div>
            <input
              type="range"
              min="40"
              max="90"
              step="5"
              value={minCoding}
              onChange={(e) => setMinCoding(parseInt(e.target.value, 10))}
              className="w-full accent-indigo-600 cursor-pointer"
            />
          </div>

          {/* Department */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Department Filter</label>
            <select
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value)}
              className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white"
            >
              <option value="all">All Departments</option>
              <option value="Computer Science">Computer Science</option>
              <option value="Information Technology">Information Technology</option>
              <option value="Electronics & Comm.">Electronics &amp; Comm.</option>
              <option value="AI & Data Science">AI &amp; Data Science</option>
            </select>
          </div>
        </div>

        {/* Live Shortlist Results Table */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-800">
              Qualified Candidates ({eligibleStudents.length} of {students.length} students &bull; {Math.round((eligibleStudents.length / students.length) * 100)}% Pass Rate)
            </span>
            <span className="text-slate-500">
              Disqualified: {disqualifiedStudents.length} students
            </span>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-xl max-h-[480px] overflow-y-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold sticky top-0 z-10 shadow-xs">
                <tr>
                  <th className="py-2.5 px-3">Student</th>
                  <th className="py-2.5 px-3">Roll No</th>
                  <th className="py-2.5 px-3">Dept</th>
                  <th className="py-2.5 px-3">CGPA</th>
                  <th className="py-2.5 px-3">Backlogs</th>
                  <th className="py-2.5 px-3">Coding</th>
                  <th className="py-2.5 px-3">Aptitude</th>
                  <th className="py-2.5 px-3">Mock Tech</th>
                  <th className="py-2.5 px-3">Success Score</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {eligibleStudents.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-2.5 px-3">
                      <div className="flex items-center gap-2">
                        <img src={s.avatar} alt="" className="w-7 h-7 rounded-full object-cover" />
                        <span className="font-bold text-slate-900">{s.name}</span>
                      </div>
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-600">{s.rollNo}</td>
                    <td className="py-2.5 px-3 text-slate-600">{s.department}</td>
                    <td className="py-2.5 px-3 font-bold text-slate-900">{s.cgpa.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-emerald-600 font-bold">{s.backlogs}</td>
                    <td className="py-2.5 px-3 font-bold text-indigo-600">{s.placement.codingScore}</td>
                    <td className="py-2.5 px-3 font-bold text-slate-800">{s.placement.aptitudeScore}</td>
                    <td className="py-2.5 px-3 text-slate-700">{s.placement.mockTechRating}/5</td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded-full font-bold bg-emerald-100 text-emerald-800 text-[11px]">
                        {s.successScore}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right">
                      <button
                        onClick={() => onSelectStudent(s)}
                        className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 underline"
                      >
                        Profile
                      </button>
                    </td>
                  </tr>
                ))}
                {eligibleStudents.length === 0 && (
                  <tr>
                    <td colSpan={10} className="py-8 text-center text-slate-400 italic">
                      No students meet the current criteria filter. Adjust sliders to expand candidate pool.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
