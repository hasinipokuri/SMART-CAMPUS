import React, { useState } from 'react';
import {
  X,
  Award,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  BookOpen,
  Calendar,
  Briefcase,
  Laptop,
  Users,
  Sparkles,
  PlusCircle,
  Clock,
  Code2,
  ChevronRight,
  ShieldAlert,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';
import { Student, ScoreFactor, Intervention } from '../types/student';

interface StudentDetailModalProps {
  student: Student | null;
  isOpen: boolean;
  onClose: () => void;
  onAddIntervention: (studentId: string, intervention: Omit<Intervention, 'id'>) => void;
  onUpdateInterventionStatus: (studentId: string, interventionId: string, status: 'pending' | 'in-progress' | 'resolved') => void;
}

export const StudentDetailModal: React.FC<StudentDetailModalProps> = ({
  student,
  isOpen,
  onClose,
  onAddIntervention,
  onUpdateInterventionStatus,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'academic' | 'attendance' | 'lms' | 'placement' | 'interventions'>('overview');
  const [targetCompany, setTargetCompany] = useState('Tier-1 Tech Companies (10-25 LPA)');
  const [loadingAi, setLoadingAi] = useState(false);
  const [aiAdvice, setAiAdvice] = useState<any>(null);
  const [showNewInterventionForm, setShowNewInterventionForm] = useState(false);

  // New intervention form state
  const [newType, setNewType] = useState<Intervention['type']>('Placement Bootcamp');
  const [newTitle, setNewTitle] = useState('');
  const [newNotes, setNewNotes] = useState('');
  const [newTargetDays, setNewTargetDays] = useState(21);

  if (!isOpen || !student) return null;

  const handleFetchAiAdvice = async () => {
    setLoadingAi(true);
    try {
      const res = await fetch('/api/ai/student-advice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ student, targetCompanyTier: targetCompany }),
      });
      const data = await res.json();
      setAiAdvice(data.advice);
    } catch (err) {
      console.error('Error getting AI advice:', err);
    } finally {
      setLoadingAi(false);
    }
  };

  const handleCreateIntervention = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const targetDate = new Date();
    targetDate.setDate(targetDate.getDate() + newTargetDays);

    onAddIntervention(student.id, {
      type: newType,
      title: newTitle.trim(),
      assignedBy: 'Academic Advisor',
      assignedDate: new Date().toISOString().split('T')[0],
      targetDate: targetDate.toISOString().split('T')[0],
      status: 'in-progress',
      notes: newNotes.trim() || 'Initiated via Smart Campus Success platform.',
    });

    setNewTitle('');
    setNewNotes('');
    setShowNewInterventionForm(false);
  };

  const getRiskBadge = (risk: string) => {
    switch (risk) {
      case 'Critical':
        return 'bg-rose-100 text-rose-800 border-rose-200';
      case 'High':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Moderate':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-4 max-h-[92vh] flex flex-col animate-in fade-in zoom-in-95 duration-150">
        
        {/* Modal Header Profile Banner */}
        <div className="px-6 py-5 bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-900 text-white shrink-0">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <img
                src={student.avatar}
                alt={student.name}
                className="w-16 h-16 rounded-2xl object-cover border-2 border-white/20 shadow-md"
              />
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-xl font-bold">{student.name}</h2>
                  <span className="font-mono text-xs px-2 py-0.5 rounded bg-white/10 text-blue-200 border border-white/10">
                    {student.rollNo}
                  </span>
                  <span className="text-xs px-2.5 py-0.5 rounded-full font-semibold bg-indigo-500/30 text-indigo-200 border border-indigo-400/30">
                    {student.segment}
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-1">
                  {student.department} &bull; Semester {student.semester} &bull; Batch {student.batch} &bull; Mentor: {student.feedback.mentorName}
                </p>
              </div>
            </div>

            {/* Quick Score Chips */}
            <div className="flex items-center gap-3">
              <div className="text-right">
                <div className="text-[10px] uppercase font-bold text-slate-300">Success Score</div>
                <div className="text-3xl font-black text-emerald-400 leading-tight">
                  {student.successScore}
                  <span className="text-xs font-normal text-slate-400">/100</span>
                </div>
              </div>

              <button
                onClick={onClose}
                className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-colors ml-2"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Quick Risk Indicator Strip */}
          <div className="flex items-center gap-3 mt-4 pt-3 border-t border-white/10 flex-wrap text-xs">
            <span className="text-slate-400 font-medium">Risk Diagnostics:</span>
            <span className={`px-2.5 py-0.5 rounded-full font-semibold border ${getRiskBadge(student.academicRisk)}`}>
              Academic Risk: {student.academicRisk}
            </span>
            <span className={`px-2.5 py-0.5 rounded-full font-semibold border ${getRiskBadge(student.placementRisk)}`}>
              Placement Risk: {student.placementRisk}
            </span>
            <span className="text-slate-300 ml-auto hidden sm:inline">
              CGPA: <strong className="text-white">{student.cgpa.toFixed(2)}</strong> &bull; 
              Attendance: <strong className="text-white">{student.attendance.overallPct}%</strong> &bull; 
              Backlogs: <strong className={student.backlogs > 0 ? 'text-rose-400' : 'text-emerald-400'}>{student.backlogs}</strong>
            </span>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-6 border-b border-slate-200 bg-slate-50 shrink-0 overflow-x-auto text-xs font-medium">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-3 px-3.5 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'overview'
                ? 'border-indigo-600 text-indigo-600 font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-4 h-4" /> Explainable Score & AI
          </button>
          <button
            onClick={() => setActiveTab('academic')}
            className={`py-3 px-3.5 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'academic'
                ? 'border-indigo-600 text-indigo-600 font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <BookOpen className="w-4 h-4" /> Academics ({student.cgpa})
          </button>
          <button
            onClick={() => setActiveTab('attendance')}
            className={`py-3 px-3.5 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'attendance'
                ? 'border-indigo-600 text-indigo-600 font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Calendar className="w-4 h-4" /> Attendance ({student.attendance.overallPct}%)
          </button>
          <button
            onClick={() => setActiveTab('lms')}
            className={`py-3 px-3.5 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'lms'
                ? 'border-indigo-600 text-indigo-600 font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Laptop className="w-4 h-4" /> LMS Activity ({student.lms.assignmentCompletionPct}%)
          </button>
          <button
            onClick={() => setActiveTab('placement')}
            className={`py-3 px-3.5 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'placement'
                ? 'border-indigo-600 text-indigo-600 font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Briefcase className="w-4 h-4" /> Placement &amp; Skills
          </button>
          <button
            onClick={() => setActiveTab('interventions')}
            className={`py-3 px-3.5 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'interventions'
                ? 'border-indigo-600 text-indigo-600 font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <ShieldAlert className="w-4 h-4" /> Interventions ({student.interventions.length})
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 p-6 overflow-y-auto space-y-6">

          {/* TAB 1: OVERVIEW & EXPLAINABLE SCORE BREAKDOWN */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Explainable Factor Decomposition (Bonus 2) */}
              <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 shadow-sm">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-indigo-600" />
                      Explainable Score Drivers (SHAP-Style Feature Attribution)
                    </h3>
                    <p className="text-xs text-slate-500">
                      Baseline campus benchmark: 50.0 pts. Detailed impact breakdown explaining {student.name}&apos;s score of {student.successScore}/100.
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] font-bold uppercase text-slate-400 block">Calculated Score</span>
                    <span className="text-xl font-black text-slate-900">{student.successScore} pts</span>
                  </div>
                </div>

                <div className="space-y-2.5 pt-2">
                  {student.explainableFactors.map((factor, idx) => (
                    <div
                      key={idx}
                      className={`p-3 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs transition-all ${
                        factor.isPositive
                          ? 'bg-emerald-50/60 border-emerald-200'
                          : 'bg-rose-50/60 border-rose-200'
                      }`}
                    >
                      <div className="flex items-start gap-2.5">
                        <div className={`p-1.5 rounded-lg shrink-0 mt-0.5 ${
                          factor.isPositive ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                        }`}>
                          {factor.isPositive ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900 text-xs">{factor.factor}</span>
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-white font-mono border border-slate-200 text-slate-600">
                              {factor.valueDisplay}
                            </span>
                            <span className="text-[10px] text-slate-500 font-medium hidden sm:inline">
                              ({factor.benchmark})
                            </span>
                          </div>
                          <p className={`text-[11px] mt-0.5 ${factor.isPositive ? 'text-emerald-900' : 'text-rose-900'}`}>
                            {factor.insight}
                          </p>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <span className={`text-sm font-black font-mono px-2 py-1 rounded-lg ${
                          factor.isPositive ? 'text-emerald-700 bg-emerald-100/70' : 'text-rose-700 bg-rose-100/70'
                        }`}>
                          {factor.impactPoints >= 0 ? `+${factor.impactPoints}` : factor.impactPoints} pts
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* AI Strategic Intervention Advisor (Gemini 3.8 Flash) */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-50 via-blue-50 to-purple-50 border border-indigo-200 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                  <div>
                    <h3 className="text-base font-bold text-indigo-950 flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-indigo-600" />
                      AI Intervention &amp; Success Roadmap
                    </h3>
                    <p className="text-xs text-indigo-900/80">
                      Powered by server-side Gemini 3.8 Flash &bull; Contextualized recommendations based on student blockers
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <select
                      value={targetCompany}
                      onChange={(e) => setTargetCompany(e.target.value)}
                      className="text-xs py-1.5 px-3 rounded-lg border border-indigo-300 bg-white text-slate-700 shadow-sm"
                    >
                      <option value="Dream Tier-1 Tech (25+ LPA)">Dream Tech (25+ LPA)</option>
                      <option value="Tier-1 Product Companies (10-25 LPA)">Tier-1 Product (10-25 LPA)</option>
                      <option value="Core Tech & Services (5-10 LPA)">Core Tech (5-10 LPA)</option>
                    </select>

                    <button
                      onClick={handleFetchAiAdvice}
                      disabled={loadingAi}
                      className="px-4 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm flex items-center gap-1.5 disabled:opacity-50 transition-colors"
                    >
                      {loadingAi ? (
                        <>
                          <Clock className="w-3.5 h-3.5 animate-spin" /> Analyzing...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-3.5 h-3.5" /> Run AI Analysis
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* AI Advice Output */}
                {aiAdvice ? (
                  <div className="space-y-4 text-xs animate-in fade-in duration-200">
                    <div className="p-3.5 bg-white/90 rounded-xl border border-indigo-200">
                      <span className="font-bold text-indigo-900 block text-xs uppercase tracking-wide mb-1">
                        Executive Diagnosis
                      </span>
                      <p className="text-slate-700 leading-relaxed">{aiAdvice.summary}</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {/* Academic Actions */}
                      <div className="p-3.5 bg-white/90 rounded-xl border border-blue-200">
                        <span className="font-bold text-blue-900 block text-xs uppercase tracking-wide mb-2 flex items-center gap-1.5">
                          <BookOpen className="w-4 h-4 text-blue-600" /> Academic &amp; Attendance Actions
                        </span>
                        <ul className="space-y-1.5 text-slate-700">
                          {aiAdvice.academicActionPlan?.map((item: string, i: number) => (
                            <li key={i} className="flex items-start gap-1.5">
                              <span className="font-bold text-blue-600">&bull;</span>
                              <span>{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Placement Actions */}
                      <div className="p-3.5 bg-white/90 rounded-xl border border-purple-200">
                        <span className="font-bold text-purple-900 block text-xs uppercase tracking-wide mb-2 flex items-center gap-1.5">
                          <Briefcase className="w-4 h-4 text-purple-600" /> 30-Day Placement Sprint
                        </span>
                        <ul className="space-y-1.5 text-slate-700">
                          {aiAdvice.placementActionPlan?.map((item: string, i: number) => (
                            <li key={i} className="flex items-start gap-1.5">
                              <span className="font-bold text-purple-600">&bull;</span>
                              <span>{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    {/* Recommended Institutional Intervention */}
                    <div className="p-3 bg-amber-50/90 rounded-xl border border-amber-200 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] font-bold uppercase text-amber-800">Prescribed Institutional Intervention</span>
                        <p className="font-bold text-amber-950 text-xs">{aiAdvice.recommendedIntervention}</p>
                      </div>
                      <button
                        onClick={() => {
                          setActiveTab('interventions');
                          setShowNewInterventionForm(true);
                          setNewTitle(aiAdvice.recommendedIntervention || 'AI Prescribed Intervention');
                        }}
                        className="px-3 py-1 bg-amber-600 text-white font-bold rounded-lg hover:bg-amber-700 text-xs shadow-sm"
                      >
                        Log Intervention
                      </button>
                    </div>

                    {aiAdvice.encouragementQuote && (
                      <p className="italic text-slate-500 text-[11px] text-center pt-1">
                        &ldquo;{aiAdvice.encouragementQuote}&rdquo;
                      </p>
                    )}
                  </div>
                ) : (
                  <div className="p-6 text-center bg-white/60 rounded-xl border border-dashed border-indigo-200">
                    <Sparkles className="w-6 h-6 text-indigo-400 mx-auto mb-2" />
                    <p className="text-xs text-indigo-900 font-medium">
                      Click &ldquo;Run AI Analysis&rdquo; to trigger Gemini 3.8 Flash model for personalized root cause analysis and action plan.
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: ACADEMICS */}
          {activeTab === 'academic' && (
            <div className="space-y-5 text-xs">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-slate-500 block text-[11px]">Cumulative CGPA</span>
                  <span className="text-2xl font-bold text-slate-900 mt-1 block">{student.cgpa.toFixed(2)}</span>
                  <span className="text-[10px] text-slate-500">Scale of 10.0</span>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-slate-500 block text-[11px]">Marks Average</span>
                  <span className="text-2xl font-bold text-slate-900 mt-1 block">{student.marksPct}%</span>
                  <span className="text-[10px] text-slate-500">Internal assessments</span>
                </div>
                <div className={`p-3.5 rounded-xl border ${student.backlogs > 0 ? 'bg-rose-50 border-rose-200' : 'bg-emerald-50 border-emerald-200'}`}>
                  <span className={student.backlogs > 0 ? 'text-rose-700 block text-[11px]' : 'text-emerald-700 block text-[11px]'}>Standing Backlogs</span>
                  <span className={`text-2xl font-bold mt-1 block ${student.backlogs > 0 ? 'text-rose-900' : 'text-emerald-900'}`}>{student.backlogs}</span>
                  <span className="text-[10px] text-slate-500">{student.backlogs === 0 ? 'Clear record' : 'Eligibility blocked'}</span>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-slate-500 block text-[11px]">Academic Sub-score</span>
                  <span className="text-2xl font-bold text-indigo-600 mt-1 block">{student.academicScore}/100</span>
                  <span className="text-[10px] text-slate-500">Weight: 30%</span>
                </div>
              </div>

              {/* Semester Subject Performance */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white">
                <h4 className="font-bold text-slate-900 text-sm mb-3">Current Semester Courses (Sem {student.semester})</h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-500 text-[11px]">
                        <th className="pb-2 font-semibold">Course Code</th>
                        <th className="pb-2 font-semibold">Subject Name</th>
                        <th className="pb-2 font-semibold">Credits</th>
                        <th className="pb-2 font-semibold">Score / 100</th>
                        <th className="pb-2 font-semibold">Grade</th>
                        <th className="pb-2 font-semibold">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {student.subjects.map((sub, i) => (
                        <tr key={i} className="hover:bg-slate-50">
                          <td className="py-2.5 font-mono text-slate-600">{sub.code}</td>
                          <td className="py-2.5 font-medium text-slate-900">{sub.subject}</td>
                          <td className="py-2.5 text-slate-600">{sub.credits}</td>
                          <td className="py-2.5 font-bold text-slate-900">{sub.score}</td>
                          <td className="py-2.5">
                            <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                              sub.grade === 'O' || sub.grade === 'A+' ? 'bg-emerald-100 text-emerald-800' :
                              sub.grade === 'F' ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-800'
                            }`}>
                              {sub.grade}
                            </span>
                          </td>
                          <td className="py-2.5">
                            {sub.score < 50 ? (
                              <span className="text-rose-600 font-semibold flex items-center gap-1">
                                <AlertTriangle className="w-3.5 h-3.5" /> Backlog
                              </span>
                            ) : (
                              <span className="text-emerald-600 font-semibold flex items-center gap-1">
                                <CheckCircle2 className="w-3.5 h-3.5" /> Cleared
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: ATTENDANCE */}
          {activeTab === 'attendance' && (
            <div className="space-y-5 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className={`p-4 rounded-xl border ${student.attendance.overallPct < 75 ? 'bg-rose-50 border-rose-200' : 'bg-emerald-50 border-emerald-200'}`}>
                  <span className="text-slate-600 block text-[11px]">Overall Attendance</span>
                  <span className={`text-3xl font-black mt-1 block ${student.attendance.overallPct < 75 ? 'text-rose-700' : 'text-emerald-700'}`}>
                    {student.attendance.overallPct}%
                  </span>
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Statutory threshold: 75% ({student.attendance.overallPct >= 75 ? 'Eligible for exams' : 'Exam detention risk!'})
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-slate-500 block text-[11px]">Total Class Hours</span>
                  <span className="text-3xl font-black text-slate-900 mt-1 block">
                    {student.attendance.classesAttended} / {student.attendance.totalClasses}
                  </span>
                  <span className="text-[10px] text-slate-500 mt-1 block">Classes attended this term</span>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-slate-500 block text-[11px]">Attendance Trend</span>
                  <span className={`text-xl font-bold mt-1 block capitalize ${
                    student.attendance.trend === 'improving' ? 'text-emerald-600' :
                    student.attendance.trend === 'declining' ? 'text-rose-600' : 'text-slate-700'
                  }`}>
                    {student.attendance.trend}
                  </span>
                  <span className="text-[10px] text-slate-500 mt-1 block">Based on 6-week moving average</span>
                </div>
              </div>

              {/* 6-Week Attendance Trend Bars */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white">
                <h4 className="font-bold text-slate-900 text-sm mb-3">6-Week Attendance Trajectory</h4>
                <div className="flex items-end gap-3 h-32 pt-4 px-2">
                  {student.attendance.weeklyHistory.map((pct, i) => (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1 h-full justify-end">
                      <span className="text-[10px] font-bold text-slate-700 font-mono">{pct}%</span>
                      <div
                        style={{ height: `${pct}%` }}
                        className={`w-full rounded-t-lg transition-all ${
                          pct < 75 ? 'bg-rose-400' : 'bg-emerald-500'
                        }`}
                      ></div>
                      <span className="text-[10px] text-slate-500 mt-1">W{i + 1}</span>
                    </div>
                  ))}
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-100 mt-3">
                  <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-emerald-500"></span> Safe (&ge; 75%)</span>
                  <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded bg-rose-400"></span> Detained (&lt; 75%)</span>
                </div>
              </div>

              {/* Subject-wise Attendance */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white">
                <h4 className="font-bold text-slate-900 text-sm mb-2">Subject-wise Attendance Distribution</h4>
                <div className="space-y-3">
                  {student.attendance.subjectWise.map((sub, i) => (
                    <div key={i}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="font-medium text-slate-800">{sub.subject}</span>
                        <span className={`font-bold ${sub.pct < 75 ? 'text-rose-600' : 'text-slate-900'}`}>{sub.pct}%</span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                        <div
                          style={{ width: `${sub.pct}%` }}
                          className={`h-full rounded-full ${sub.pct < 75 ? 'bg-rose-500' : 'bg-indigo-600'}`}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: LMS */}
          {activeTab === 'lms' && (
            <div className="space-y-5 text-xs">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-slate-500 block text-[11px]">Assignment Completion</span>
                  <span className="text-2xl font-bold text-slate-900 mt-1 block">{student.lms.assignmentCompletionPct}%</span>
                  <span className="text-[10px] text-slate-500">Coursework submitted</span>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-slate-500 block text-[11px]">Weekly Login Frequency</span>
                  <span className="text-2xl font-bold text-slate-900 mt-1 block">{student.lms.weeklyLogins} days</span>
                  <span className="text-[10px] text-slate-500">Per 7-day period</span>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-slate-500 block text-[11px]">Hours Spent Weekly</span>
                  <span className="text-2xl font-bold text-slate-900 mt-1 block">{student.lms.hoursSpentWeekly} hrs</span>
                  <span className="text-[10px] text-slate-500">On LMS materials &amp; labs</span>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-slate-500 block text-[11px]">Quiz Average</span>
                  <span className="text-2xl font-bold text-slate-900 mt-1 block">{student.lms.quizzesAverage}%</span>
                  <span className="text-[10px] text-slate-500">Online checkpoint tests</span>
                </div>
              </div>

              <div className="p-4 rounded-xl border border-slate-200 bg-white">
                <h4 className="font-bold text-slate-900 text-sm mb-2">Digital Engagement Insight</h4>
                <p className="text-slate-600 leading-relaxed text-xs">
                  Student was last active <strong>{student.lms.lastActiveHoursAgo} hours ago</strong>. 
                  Contributed <strong>{student.lms.forumContributions}</strong> peer forum discussions. 
                  {student.lms.assignmentCompletionPct < 70 ? (
                    <span className="text-rose-600 block mt-1 font-semibold">
                      Alert: Falling behind on weekly laboratory uploads and reading assignments.
                    </span>
                  ) : (
                    <span className="text-emerald-600 block mt-1 font-semibold">
                      Positive: Consistently meets digital coursework deadlines.
                    </span>
                  )}
                </p>
              </div>
            </div>
          )}

          {/* TAB 5: PLACEMENT & SKILLS */}
          {activeTab === 'placement' && (
            <div className="space-y-5 text-xs">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className={`p-3.5 rounded-xl border ${student.placement.codingScore < 60 ? 'bg-rose-50 border-rose-200' : 'bg-emerald-50 border-emerald-200'}`}>
                  <span className="text-slate-600 block text-[11px]">Coding Assessment</span>
                  <span className={`text-2xl font-bold mt-1 block ${student.placement.codingScore < 60 ? 'text-rose-800' : 'text-emerald-800'}`}>
                    {student.placement.codingScore}/100
                  </span>
                  <span className="text-[10px] text-slate-500">DSA &amp; Problem Solving</span>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-slate-500 block text-[11px]">Quantitative Aptitude</span>
                  <span className="text-2xl font-bold text-slate-900 mt-1 block">{student.placement.aptitudeScore}/100</span>
                  <span className="text-[10px] text-slate-500">Logic &amp; Reasoning</span>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-slate-500 block text-[11px]">Mock Tech Interview</span>
                  <span className="text-2xl font-bold text-slate-900 mt-1 block">{student.placement.mockTechRating} / 5.0</span>
                  <span className="text-[10px] text-slate-500">Faculty/Alumni Panel</span>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-slate-500 block text-[11px]">Resume ATS Score</span>
                  <span className="text-2xl font-bold text-slate-900 mt-1 block">{student.placement.resumeAtsScore}/100</span>
                  <span className="text-[10px] text-slate-500">Keyword compatibility</span>
                </div>
              </div>

              {/* Verified Certifications & Hackathons */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white">
                <h4 className="font-bold text-slate-900 text-sm mb-3">Industry Certifications &amp; Credentials</h4>
                {student.engagement.certifications.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {student.engagement.certifications.map((c, i) => (
                      <div key={i} className="p-2.5 rounded-lg bg-indigo-50/60 border border-indigo-100 flex items-center justify-between">
                        <div>
                          <p className="font-bold text-indigo-950 text-xs">{c.title}</p>
                          <span className="text-[10px] text-indigo-700">{c.issuer} &bull; {c.date}</span>
                        </div>
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-slate-400 italic">No verified industry certifications logged yet.</p>
                )}
              </div>

              {/* Skills Radar / Progress */}
              <div className="p-4 rounded-xl border border-slate-200 bg-white">
                <h4 className="font-bold text-slate-900 text-sm mb-3">Core Skills vs Placement Target Level</h4>
                <div className="space-y-3">
                  {student.skills.map((skill, i) => (
                    <div key={i}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="font-medium text-slate-800">{skill.name}</span>
                        <span className="text-slate-500 font-mono">
                          Current: <strong className="text-slate-900">{skill.currentScore}</strong> / Target: {skill.targetScore}
                        </span>
                      </div>
                      <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden flex">
                        <div
                          style={{ width: `${skill.currentScore}%` }}
                          className={`h-full ${skill.currentScore >= skill.targetScore ? 'bg-emerald-500' : 'bg-indigo-600'}`}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: INTERVENTIONS */}
          {activeTab === 'interventions' && (
            <div className="space-y-5 text-xs">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">Actionable Interventions</h4>
                  <p className="text-slate-500 text-xs">Closed-loop institutional support actions assigned to {student.name}</p>
                </div>
                <button
                  onClick={() => setShowNewInterventionForm(true)}
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
                >
                  <PlusCircle className="w-4 h-4" /> Add Intervention
                </button>
              </div>

              {/* Form to Add New Intervention */}
              {showNewInterventionForm && (
                <form onSubmit={handleCreateIntervention} className="p-4 rounded-xl bg-slate-50 border border-indigo-200 space-y-3 animate-in fade-in duration-150">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-indigo-950 text-xs uppercase tracking-wider">Log New Actionable Intervention</span>
                    <button type="button" onClick={() => setShowNewInterventionForm(false)} className="text-slate-400 hover:text-slate-600">
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-1">Intervention Type</label>
                      <select
                        value={newType}
                        onChange={(e) => setNewType(e.target.value as any)}
                        className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white"
                      >
                        <option value="Placement Bootcamp">Placement Bootcamp</option>
                        <option value="Remedial Tutoring">Remedial Tutoring</option>
                        <option value="Attendance Counseling">Attendance Counseling</option>
                        <option value="Academic Warning">Academic Warning</option>
                        <option value="Faculty Mentorship">Faculty Mentorship</option>
                        <option value="Skill Workshop">Skill Workshop</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-1">Target Duration</label>
                      <select
                        value={newTargetDays}
                        onChange={(e) => setNewTargetDays(Number(e.target.value))}
                        className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white"
                      >
                        <option value={7}>1 Week Sprint</option>
                        <option value={14}>2 Weeks</option>
                        <option value={21}>3 Weeks</option>
                        <option value={30}>1 Month</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 mb-1">Action Title / Program</label>
                    <input
                      type="text"
                      placeholder="e.g. Mandatory DSA LeetCode 30-Day Sprint"
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 mb-1">Notes &amp; Specific Goals</label>
                    <textarea
                      placeholder="Specify deliverables, mentors assigned, and meeting cadence..."
                      value={newNotes}
                      onChange={(e) => setNewNotes(e.target.value)}
                      className="w-full text-xs p-2 rounded-lg border border-slate-300 bg-white h-16"
                    />
                  </div>

                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowNewInterventionForm(false)}
                      className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-200 rounded-lg"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm"
                    >
                      Assign &amp; Notify Student
                    </button>
                  </div>
                </form>
              )}

              {/* Interventions List */}
              <div className="space-y-3">
                {student.interventions.length > 0 ? (
                  student.interventions.map((int) => (
                    <div
                      key={int.id}
                      className="p-4 rounded-xl border border-slate-200 bg-white shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900 text-sm">{int.title}</span>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 font-semibold">
                            {int.type}
                          </span>
                        </div>
                        <p className="text-slate-600 text-xs mt-1">{int.notes}</p>
                        <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-2">
                          <span>Assigned by: <strong>{int.assignedBy}</strong></span>
                          <span>Target: <strong>{int.targetDate}</strong></span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <select
                          value={int.status}
                          onChange={(e) => onUpdateInterventionStatus(student.id, int.id, e.target.value as any)}
                          className={`text-xs font-semibold py-1 px-2.5 rounded-lg border ${
                            int.status === 'resolved'
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                              : int.status === 'in-progress'
                              ? 'bg-amber-50 text-amber-800 border-amber-300'
                              : 'bg-slate-50 text-slate-800 border-slate-300'
                          }`}
                        >
                          <option value="pending">Pending</option>
                          <option value="in-progress">In-Progress</option>
                          <option value="resolved">Resolved</option>
                        </select>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-8 text-center bg-slate-50 rounded-xl border border-dashed border-slate-300">
                    <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                    <p className="text-slate-700 font-medium">No open interventions for {student.name}.</p>
                    <p className="text-slate-500 text-xs mt-0.5">Click &ldquo;Add Intervention&rdquo; above to log an institutional action.</p>
                  </div>
                )}
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-3.5 bg-slate-50 border-t border-slate-200 shrink-0 text-xs">
          <span className="text-slate-500">Student Profile &bull; Last updated today &bull; Verified Academic Record</span>
          <button
            onClick={onClose}
            className="px-4 py-2 font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg shadow-sm transition-colors"
          >
            Close View
          </button>
        </div>
      </div>
    </div>
  );
};
