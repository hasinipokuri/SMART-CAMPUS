import React, { useState, useMemo } from 'react';
import {
  Users,
  AlertTriangle,
  TrendingUp,
  Award,
  Layers,
  Search,
  Filter,
  Download,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ShieldAlert,
  Calendar,
  Laptop,
  Briefcase,
  ChevronDown,
  Compass,
  FileSpreadsheet,
  Clock,
  Zap,
} from 'lucide-react';
import { Student, StudentSegment, RiskLevel, CohortStats } from '../types/student';
import { computeCohortStats } from '../utils/analyticsEngine';

interface FacultyDashboardProps {
  students: Student[];
  onSelectStudent: (student: Student) => void;
  onBatchIntervention: (type: string, title: string, studentIds: string[]) => void;
  onOpenMethodology: () => void;
  onOpenPresentation: () => void;
}

export const FacultyDashboard: React.FC<FacultyDashboardProps> = ({
  students,
  onSelectStudent,
  onBatchIntervention,
  onOpenMethodology,
  onOpenPresentation,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'overview' | 'segmentation' | 'risk-triage' | 'directory' | 'ai-briefing'>('overview');

  // Filters state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState('all');
  const [selectedSegment, setSelectedSegment] = useState<string>('all');
  const [selectedRisk, setSelectedRisk] = useState<string>('all');
  const [attendanceFilter, setAttendanceFilter] = useState<'all' | 'below75'>('all');

  // Batch selection
  const [selectedStudentIds, setSelectedStudentIds] = useState<string[]>([]);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState<number>(25);

  // AI Briefing state
  const [loadingAiBrief, setLoadingAiBrief] = useState(false);
  const [aiBriefing, setAiBriefing] = useState<any>(null);

  // Compute stats
  const stats = useMemo(() => computeCohortStats(students), [students]);

  // Filtered students for Directory & Explorer
  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matches = s.name.toLowerCase().includes(q) || s.rollNo.toLowerCase().includes(q) || s.email.toLowerCase().includes(q);
        if (!matches) return false;
      }
      if (selectedDept !== 'all' && s.department !== selectedDept) return false;
      if (selectedSegment !== 'all' && s.segment !== selectedSegment) return false;
      if (selectedRisk !== 'all' && s.overallRisk !== selectedRisk) return false;
      if (attendanceFilter === 'below75' && s.attendance.overallPct >= 75) return false;
      return true;
    });
  }, [students, searchQuery, selectedDept, selectedSegment, selectedRisk, attendanceFilter]);

  const totalPages = Math.ceil(filteredStudents.length / pageSize) || 1;
  const paginatedStudents = useMemo(() => {
    if (pageSize >= 1000) return filteredStudents;
    const start = (currentPage - 1) * pageSize;
    return filteredStudents.slice(start, start + pageSize);
  }, [filteredStudents, currentPage, pageSize]);

  // Toggle selection
  const toggleSelectStudent = (id: string) => {
    setSelectedStudentIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (selectedStudentIds.length === filteredStudents.length) {
      setSelectedStudentIds([]);
    } else {
      setSelectedStudentIds(filteredStudents.map((s) => s.id));
    }
  };

  // Export filtered students CSV
  const handleExportCsv = () => {
    const headers = ['Roll No', 'Name', 'Department', 'Semester', 'CGPA', 'Backlogs', 'Attendance %', 'LMS Completion %', 'Coding Score', 'Aptitude Score', 'Success Score', 'Academic Risk', 'Placement Risk', 'Segment'];
    const rows = filteredStudents.map((s) => [
      s.rollNo,
      s.name,
      s.department,
      s.semester,
      s.cgpa.toFixed(2),
      s.backlogs,
      s.attendance.overallPct,
      s.lms.assignmentCompletionPct,
      s.placement.codingScore,
      s.placement.aptitudeScore,
      s.successScore,
      s.academicRisk,
      s.placementRisk,
      `"${s.segment}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'SmartCampus_Cohort_Analytics.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Fetch AI Cohort Briefing
  const fetchAiCohortBrief = async () => {
    setLoadingAiBrief(true);
    try {
      const res = await fetch('/api/ai/cohort-summary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cohortStats: stats }),
      });
      const data = await res.json();
      setAiBriefing(data.summary);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingAiBrief(false);
    }
  };

  const getRiskColor = (risk: RiskLevel) => {
    switch (risk) {
      case 'Critical': return 'bg-rose-100 text-rose-800 border-rose-300';
      case 'High': return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'Moderate': return 'bg-blue-100 text-blue-800 border-blue-300';
      default: return 'bg-emerald-100 text-emerald-800 border-emerald-300';
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Welcome & Control Header */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-950 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-blue-500/20 text-blue-300 border border-blue-400/30">
              Faculty &amp; Administrator Portal
            </span>
            <span className="text-xs text-slate-300 font-mono">Real-time Campus Intelligence</span>
          </div>
          <h1 className="text-2xl font-black">Cohort Analytics &amp; Decision Intelligence</h1>
          <p className="text-xs text-blue-200 mt-1">
            Unified multi-source tracking across {students.length} students &bull; Academic, Attendance, LMS, and Placement readiness.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={onOpenMethodology}
            className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/15 transition-colors"
          >
            Scoring Rationale
          </button>
          <button
            onClick={onOpenPresentation}
            className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md transition-colors"
          >
            Slide Deck Demo
          </button>
        </div>
      </div>

      {/* TOP 5 KPI SUMMARY CARDS */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5">
        {/* 1. Avg Success Score */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
          <span className="text-[11px] font-bold uppercase text-slate-500 tracking-wider">Avg Success Score</span>
          <div className="flex items-baseline gap-1.5 my-1.5">
            <span className="text-3xl font-black text-slate-900">{stats.avgSuccessScore}</span>
            <span className="text-xs text-slate-400">/ 100</span>
          </div>
          <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded-full w-fit">
            Good Standing Overall
          </span>
        </div>

        {/* 2. Academic At-Risk */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
          <span className="text-[11px] font-bold uppercase text-slate-500 tracking-wider">Academic At-Risk</span>
          <div className="flex items-baseline gap-1.5 my-1.5">
            <span className="text-3xl font-black text-rose-600">{stats.academicAtRiskCount}</span>
            <span className="text-xs text-slate-400">({stats.academicAtRiskPct}%)</span>
          </div>
          <span className="text-[10px] text-rose-700 font-semibold bg-rose-50 px-2 py-0.5 rounded-full w-fit">
            CGPA &lt; 6.8 or Backlog
          </span>
        </div>

        {/* 3. Placement At-Risk */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
          <span className="text-[11px] font-bold uppercase text-slate-500 tracking-wider">Placement At-Risk</span>
          <div className="flex items-baseline gap-1.5 my-1.5">
            <span className="text-3xl font-black text-purple-600">{stats.placementAtRiskCount}</span>
            <span className="text-xs text-slate-400">({stats.placementAtRiskPct}%)</span>
          </div>
          <span className="text-[10px] text-purple-700 font-semibold bg-purple-50 px-2 py-0.5 rounded-full w-fit">
            Coding &lt; 60 / Aptitude &lt; 55
          </span>
        </div>

        {/* 4. Average Attendance */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
          <span className="text-[11px] font-bold uppercase text-slate-500 tracking-wider">Avg Attendance</span>
          <div className="flex items-baseline gap-1.5 my-1.5">
            <span className={`text-3xl font-black ${stats.avgAttendance < 75 ? 'text-rose-600' : 'text-slate-900'}`}>
              {stats.avgAttendance}%
            </span>
          </div>
          <span className="text-[10px] text-amber-700 font-semibold bg-amber-50 px-2 py-0.5 rounded-full w-fit">
            Statutory Limit: 75%
          </span>
        </div>

        {/* 5. LMS Assignment Completion */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between col-span-2 lg:col-span-1">
          <span className="text-[11px] font-bold uppercase text-slate-500 tracking-wider">LMS Completion</span>
          <div className="flex items-baseline gap-1.5 my-1.5">
            <span className="text-3xl font-black text-slate-900">{stats.avgLmsCompletion}%</span>
          </div>
          <span className="text-[10px] text-blue-700 font-semibold bg-blue-50 px-2 py-0.5 rounded-full w-fit">
            Weekly Submissions
          </span>
        </div>
      </div>

      {/* DASHBOARD SUB-TABS */}
      <div className="border-b border-slate-200 flex items-center gap-2 overflow-x-auto text-xs font-bold text-slate-600">
        <button
          onClick={() => setActiveSubTab('overview')}
          className={`py-3 px-4 border-b-2 transition-colors flex items-center gap-1.5 ${
            activeSubTab === 'overview' ? 'border-indigo-600 text-indigo-600' : 'border-transparent hover:text-slate-900'
          }`}
        >
          <TrendingUp className="w-4 h-4" /> Cohort Health &amp; Trends
        </button>
        <button
          onClick={() => setActiveSubTab('segmentation')}
          className={`py-3 px-4 border-b-2 transition-colors flex items-center gap-1.5 ${
            activeSubTab === 'segmentation' ? 'border-indigo-600 text-indigo-600' : 'border-transparent hover:text-slate-900'
          }`}
        >
          <Compass className="w-4 h-4" /> Segmentation Matrix (Bonus 1)
        </button>
        <button
          onClick={() => setActiveSubTab('risk-triage')}
          className={`py-3 px-4 border-b-2 transition-colors flex items-center gap-1.5 ${
            activeSubTab === 'risk-triage' ? 'border-indigo-600 text-indigo-600' : 'border-transparent hover:text-slate-900'
          }`}
        >
          <ShieldAlert className="w-4 h-4" /> Early Warning &amp; Triage ({stats.criticalInterventionCount})
        </button>
        <button
          onClick={() => setActiveSubTab('directory')}
          className={`py-3 px-4 border-b-2 transition-colors flex items-center gap-1.5 ${
            activeSubTab === 'directory' ? 'border-indigo-600 text-indigo-600' : 'border-transparent hover:text-slate-900'
          }`}
        >
          <Users className="w-4 h-4" /> Student Directory &amp; Interventions
        </button>
        <button
          onClick={() => setActiveSubTab('ai-briefing')}
          className={`py-3 px-4 border-b-2 transition-colors flex items-center gap-1.5 ${
            activeSubTab === 'ai-briefing' ? 'border-indigo-600 text-indigo-600' : 'border-transparent hover:text-slate-900'
          }`}
        >
          <Sparkles className="w-4 h-4" /> AI Council Briefing (Gemini 3.8)
        </button>
      </div>

      {/* SUB-TAB 1: COHORT OVERVIEW & TRENDS */}
      {activeSubTab === 'overview' && (
        <div className="space-y-6">
          {/* Department Breakdown Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {Object.entries(stats.deptSummary).map(([dept, dStats], i) => (
              <div key={i} className="p-4 rounded-xl border border-slate-200 bg-white shadow-sm space-y-2">
                <span className="font-bold text-slate-900 text-xs">{dept}</span>
                <div className="flex justify-between items-baseline pt-1">
                  <span className="text-2xl font-black text-indigo-600">{dStats.avgSuccess}</span>
                  <span className="text-xs text-slate-500">{dStats.count} Students</span>
                </div>
                <div className="text-[11px] text-slate-500 flex justify-between pt-1 border-t border-slate-100">
                  <span>At-Risk Exposure:</span>
                  <span className={`font-bold ${dStats.atRiskPct > 30 ? 'text-rose-600' : 'text-slate-700'}`}>
                    {dStats.atRiskPct}%
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Multi-Source Correlation Insights */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Correlation 1: Attendance vs CGPA */}
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Calendar className="w-4 h-4 text-amber-600" />
                Attendance vs. Academic CGPA Correlation
              </h3>
              <p className="text-xs text-slate-500">
                Noticeable trend: Students with attendance &lt; 75% show a 2.1-point lower average CGPA and 4x higher risk of backlogs.
              </p>
              <div className="space-y-2 pt-2 text-xs">
                {students.slice(0, 5).map((s) => (
                  <div key={s.id} className="flex items-center justify-between p-2 rounded-lg bg-slate-50 border border-slate-100">
                    <span className="font-semibold text-slate-800">{s.name} ({s.department})</span>
                    <div className="flex items-center gap-3 font-mono text-[11px]">
                      <span className={s.attendance.overallPct < 75 ? 'text-rose-600 font-bold' : 'text-slate-600'}>
                        Att: {s.attendance.overallPct}%
                      </span>
                      <span className="font-bold text-slate-900">CGPA: {s.cgpa.toFixed(2)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Correlation 2: Theory CGPA vs Placement Coding Readiness */}
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-purple-600" />
                The &ldquo;Bookworm Paradox&rdquo;: High GPA with Low Coding
              </h3>
              <p className="text-xs text-slate-500">
                Several top-GPA students fail Day-1 tech screenings due to low algorithmic coding practice.
              </p>
              <div className="space-y-2 pt-2 text-xs">
                {students
                  .filter((s) => s.segment === 'High Academics - Low Placement')
                  .slice(0, 4)
                  .map((s) => (
                    <div key={s.id} className="flex items-center justify-between p-2 rounded-lg bg-amber-50/70 border border-amber-200">
                      <div>
                        <span className="font-bold text-amber-950">{s.name}</span>
                        <span className="text-[10px] text-amber-700 block">Needs hands-on DSA bootcamp</span>
                      </div>
                      <div className="text-right font-mono text-[11px]">
                        <span className="text-emerald-700 font-bold block">CGPA: {s.cgpa.toFixed(2)}</span>
                        <span className="text-rose-700 font-bold block">Coding: {s.placement.codingScore}/100</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 2: STUDENT SEGMENTATION MATRIX (BONUS FEATURE 1) */}
      {activeSubTab === 'segmentation' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                  <Compass className="w-5 h-5 text-indigo-600" />
                  Interactive 4-Quadrant Behavioral Segmentation Matrix
                </h3>
                <p className="text-xs text-slate-500">
                  X-Axis: Academic Performance Index &bull; Y-Axis: Placement &amp; Coding Readiness. Click any student bubble to view full profile.
                </p>
              </div>

              <div className="flex items-center gap-2 text-xs font-semibold">
                <span className="text-slate-500">Filter Segment:</span>
                <select
                  value={selectedSegment}
                  onChange={(e) => setSelectedSegment(e.target.value)}
                  className="py-1 px-2.5 rounded-lg border border-slate-300 bg-slate-50 text-slate-800"
                >
                  <option value="all">All Segments ({students.length})</option>
                  <option value="Consistent High Achievers">Consistent High Achievers</option>
                  <option value="High Academics - Low Placement">High Academics - Low Placement</option>
                  <option value="High Placement - Academic/Attendance At-Risk">High Placement - Academic At-Risk</option>
                  <option value="Silent Strugglers / Disengaged">Silent Strugglers / Disengaged</option>
                  <option value="Well-Rounded Core">Well-Rounded Core</option>
                </select>
              </div>
            </div>

            {/* 2D Quadrant Matrix Visual Canvas */}
            <div className="relative w-full h-96 bg-slate-50 rounded-2xl border-2 border-slate-200 overflow-hidden p-6 select-none shadow-inner">
              {/* Quadrant Divider Axis Lines */}
              <div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-slate-300"></div>
              <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-slate-300"></div>

              {/* Quadrant Labels */}
              {/* Top-Left */}
              <div className="absolute top-3 left-4 text-[11px] font-bold text-cyan-800 bg-cyan-100/90 px-2.5 py-1 rounded-lg border border-cyan-300 shadow-sm">
                Top-Left: &ldquo;Hidden Prodigies&rdquo; (High Coding, Attendance/GPA Risk)
              </div>
              {/* Top-Right */}
              <div className="absolute top-3 right-4 text-[11px] font-bold text-indigo-800 bg-indigo-100/90 px-2.5 py-1 rounded-lg border border-indigo-300 shadow-sm">
                Top-Right: Consistent High Achievers (Dream Tier 1 Ready)
              </div>
              {/* Bottom-Left */}
              <div className="absolute bottom-3 left-4 text-[11px] font-bold text-rose-800 bg-rose-100/90 px-2.5 py-1 rounded-lg border border-rose-300 shadow-sm">
                Bottom-Left: Silent Strugglers / Disengaged (Urgent Support)
              </div>
              {/* Bottom-Right */}
              <div className="absolute bottom-3 right-4 text-[11px] font-bold text-amber-800 bg-amber-100/90 px-2.5 py-1 rounded-lg border border-amber-300 shadow-sm">
                Bottom-Right: &ldquo;The Bookworms&rdquo; (High GPA, Low Coding Readiness)
              </div>

              {/* Student Bubbles plotted on (Academic X, Placement Y) */}
              {students.map((s) => {
                // Academic normalized 0 to 100 on X-axis (offset padding 10% to 90%)
                const posX = 10 + (s.academicScore / 100) * 80;
                // Placement normalized 0 to 100 on Y-axis (invert so high is at top: 90% to 10%)
                const posY = 90 - (s.placementReadinessScore / 100) * 80;

                const isHighlight = selectedSegment === 'all' || s.segment === selectedSegment;

                return (
                  <button
                    key={s.id}
                    onClick={() => onSelectStudent(s)}
                    style={{ left: `${posX}%`, top: `${posY}%` }}
                    className={`absolute -translate-x-1/2 -translate-y-1/2 group transition-all duration-200 z-10 ${
                      isHighlight ? 'scale-100 opacity-100' : 'scale-75 opacity-25'
                    }`}
                  >
                    <div className="relative">
                      <img
                        src={s.avatar}
                        alt={s.name}
                        className={`w-9 h-9 rounded-full object-cover border-2 shadow-md transition-transform group-hover:scale-125 ${
                          s.segment === 'Consistent High Achievers' ? 'border-indigo-500' :
                          s.segment === 'High Academics - Low Placement' ? 'border-amber-500' :
                          s.segment === 'High Placement - Academic/Attendance At-Risk' ? 'border-cyan-500' :
                          s.segment === 'Silent Strugglers / Disengaged' ? 'border-rose-500' : 'border-slate-500'
                        }`}
                      />
                      <span className="absolute -bottom-1 -right-1 px-1 rounded-full text-[9px] font-black bg-slate-900 text-white font-mono">
                        {s.successScore}
                      </span>
                    </div>

                    {/* Tooltip Hover Badge */}
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:flex flex-col items-center bg-slate-900 text-white text-[11px] py-1 px-2.5 rounded-lg whitespace-nowrap shadow-xl z-30">
                      <span className="font-bold">{s.name} ({s.department})</span>
                      <span className="text-[10px] text-slate-300">
                        Score: {s.successScore} &bull; CGPA: {s.cgpa} &bull; Coding: {s.placement.codingScore}
                      </span>
                      <span className="text-[9px] text-indigo-300 font-medium">{s.segment}</span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Segment Explanations & Targeted Actions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
              <div className="p-3.5 rounded-xl bg-indigo-50 border border-indigo-200">
                <span className="font-bold text-indigo-950 block">Consistent High Achievers ({stats.segmentDistribution['Consistent High Achievers']})</span>
                <p className="text-indigo-900/80 mt-1">High CGPA and competitive coding.</p>
                <span className="font-bold text-indigo-700 block mt-2 text-[11px]">&rarr; Action: Nominate for Tier-1 Super Dream placements.</span>
              </div>
              <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200">
                <span className="font-bold text-amber-950 block">&ldquo;The Bookworms&rdquo; ({stats.segmentDistribution['High Academics - Low Placement']})</span>
                <p className="text-amber-900/80 mt-1">Exceptional theory, but low coding test scores.</p>
                <span className="font-bold text-amber-700 block mt-2 text-[11px]">&rarr; Action: Mandatory DSA &amp; live whiteboard coding lab.</span>
              </div>
              <div className="p-3.5 rounded-xl bg-cyan-50 border border-cyan-200">
                <span className="font-bold text-cyan-950 block">&ldquo;Hidden Prodigies&rdquo; ({stats.segmentDistribution['High Placement - Academic/Attendance At-Risk']})</span>
                <p className="text-cyan-900/80 mt-1">Top developers risking exam detention or backlogs.</p>
                <span className="font-bold text-cyan-700 block mt-2 text-[11px]">&rarr; Action: Compulsory attendance recovery contracts.</span>
              </div>
              <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200">
                <span className="font-bold text-rose-950 block">Silent Strugglers ({stats.segmentDistribution['Silent Strugglers / Disengaged']})</span>
                <p className="text-rose-900/80 mt-1">Low LMS cadence, attendance slip, low GPA.</p>
                <span className="font-bold text-rose-700 block mt-2 text-[11px]">&rarr; Action: Faculty counseling &amp; peer study buddies.</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 3: EARLY WARNING & RISK TRIAGE */}
      {activeSubTab === 'risk-triage' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-rose-600" />
                Early Warning &amp; Multi-Risk Triage Board
              </h3>
              <p className="text-xs text-slate-500">
                Categorized according to academic failure, exam detention cliff (&lt;75% attendance), and placement ineligibility.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  const criticalIds = students.filter((s) => s.overallRisk === 'Critical').map((s) => s.id);
                  onBatchIntervention('Academic Warning', 'Parent-Faculty Dean Consultation Notice', criticalIds);
                }}
                className="px-3.5 py-1.5 text-xs font-bold rounded-xl bg-rose-600 hover:bg-rose-700 text-white shadow-sm transition-colors"
              >
                Send Dean Consultations ({students.filter((s) => s.overallRisk === 'Critical').length})
              </button>
            </div>
          </div>

          {/* 3 Risk Triage Columns */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Critical Column */}
            <div className="p-4 rounded-2xl bg-rose-50/70 border border-rose-200 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-rose-200">
                <span className="font-bold text-rose-950 text-xs flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-600"></span>
                  Critical Risk ({students.filter((s) => s.overallRisk === 'Critical').length})
                </span>
                <span className="text-[10px] text-rose-700 font-semibold">Immediate Action</span>
              </div>

              <div className="space-y-2.5">
                {students
                  .filter((s) => s.overallRisk === 'Critical')
                  .map((s) => (
                    <div
                      key={s.id}
                      onClick={() => onSelectStudent(s)}
                      className="p-3 bg-white rounded-xl border border-rose-200 shadow-sm hover:shadow-md cursor-pointer transition-all"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 text-xs">{s.name}</span>
                        <span className="text-rose-600 font-bold font-mono text-xs">{s.successScore} pts</span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">{s.department} &bull; Roll: {s.rollNo}</p>
                      <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-rose-700 font-semibold">
                        <span>Attendance: {s.attendance.overallPct}%</span>
                        <span>Backlogs: {s.backlogs}</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>

            {/* High Risk Column */}
            <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-amber-200">
                <span className="font-bold text-amber-950 text-xs flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-600"></span>
                  High Risk ({students.filter((s) => s.overallRisk === 'High').length})
                </span>
                <span className="text-[10px] text-amber-700 font-semibold">Intervention Required</span>
              </div>

              <div className="space-y-2.5">
                {students
                  .filter((s) => s.overallRisk === 'High')
                  .map((s) => (
                    <div
                      key={s.id}
                      onClick={() => onSelectStudent(s)}
                      className="p-3 bg-white rounded-xl border border-amber-200 shadow-sm hover:shadow-md cursor-pointer transition-all"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 text-xs">{s.name}</span>
                        <span className="text-amber-600 font-bold font-mono text-xs">{s.successScore} pts</span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">{s.department} &bull; Roll: {s.rollNo}</p>
                      <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-amber-700 font-semibold">
                        <span>Att: {s.attendance.overallPct}%</span>
                        <span>Coding: {s.placement.codingScore}/100</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>

            {/* Moderate / Watchlist Column */}
            <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-blue-200">
                <span className="font-bold text-blue-950 text-xs flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
                  Moderate / Watchlist ({students.filter((s) => s.overallRisk === 'Moderate').length})
                </span>
                <span className="text-[10px] text-blue-700 font-semibold">Monitor Closely</span>
              </div>

              <div className="space-y-2.5">
                {students
                  .filter((s) => s.overallRisk === 'Moderate')
                  .map((s) => (
                    <div
                      key={s.id}
                      onClick={() => onSelectStudent(s)}
                      className="p-3 bg-white rounded-xl border border-blue-200 shadow-sm hover:shadow-md cursor-pointer transition-all"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-900 text-xs">{s.name}</span>
                        <span className="text-blue-600 font-bold font-mono text-xs">{s.successScore} pts</span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">{s.department} &bull; Roll: {s.rollNo}</p>
                      <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-blue-700 font-semibold">
                        <span>LMS: {s.lms.assignmentCompletionPct}%</span>
                        <span>CGPA: {s.cgpa.toFixed(2)}</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 4: FULL STUDENT DIRECTORY & BATCH INTERVENTIONS */}
      {activeSubTab === 'directory' && (
        <div className="space-y-4">
          {/* Search & Filters Bar */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex items-center gap-2 flex-1 max-w-md">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search student by name, roll number, email..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-300 bg-slate-50 focus:bg-white focus:outline-none"
                />
              </div>
            </div>

            <div className="flex items-center gap-2 flex-wrap text-xs">
              <select
                value={selectedDept}
                onChange={(e) => setSelectedDept(e.target.value)}
                className="py-1.5 px-3 rounded-xl border border-slate-300 bg-white"
              >
                <option value="all">All Departments</option>
                <option value="Computer Science">Computer Science</option>
                <option value="Information Technology">Information Technology</option>
                <option value="Electronics & Comm.">Electronics &amp; Comm.</option>
                <option value="AI & Data Science">AI &amp; Data Science</option>
              </select>

              <select
                value={selectedRisk}
                onChange={(e) => setSelectedRisk(e.target.value)}
                className="py-1.5 px-3 rounded-xl border border-slate-300 bg-white"
              >
                <option value="all">All Risk Levels</option>
                <option value="Critical">Critical</option>
                <option value="High">High</option>
                <option value="Moderate">Moderate</option>
                <option value="Low">Low</option>
              </select>

              <button
                onClick={() => setAttendanceFilter(attendanceFilter === 'all' ? 'below75' : 'all')}
                className={`py-1.5 px-3 rounded-xl border transition-colors ${
                  attendanceFilter === 'below75'
                    ? 'bg-rose-600 text-white border-rose-600 font-bold'
                    : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
                }`}
              >
                {attendanceFilter === 'below75' ? 'Attendance < 75% Only' : 'Show All Attendance'}
              </button>

              <button
                onClick={handleExportCsv}
                className="py-1.5 px-3.5 rounded-xl bg-slate-900 text-white hover:bg-slate-800 flex items-center gap-1.5 font-bold shadow-sm"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" /> Export CSV
              </button>
            </div>
          </div>

          {/* Batch Actions Bar (when students are checked) */}
          {selectedStudentIds.length > 0 && (
            <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-xl flex items-center justify-between text-xs animate-in fade-in duration-150">
              <span className="font-bold text-indigo-950">
                {selectedStudentIds.length} Student(s) Selected for Batch Action
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => onBatchIntervention('Placement Bootcamp', 'Intensive DSA & Code Drill', selectedStudentIds)}
                  className="px-3 py-1 bg-indigo-600 text-white font-bold rounded-lg hover:bg-indigo-700"
                >
                  Enroll in Bootcamp
                </button>
                <button
                  onClick={() => onBatchIntervention('Attendance Counseling', 'Compulsory Attendance Recovery', selectedStudentIds)}
                  className="px-3 py-1 bg-amber-600 text-white font-bold rounded-lg hover:bg-amber-700"
                >
                  Issue Attendance Notice
                </button>
                <button
                  onClick={() => setSelectedStudentIds([])}
                  className="px-2 py-1 text-slate-500 hover:text-slate-800"
                >
                  Deselect
                </button>
              </div>
            </div>
          )}

          {/* Data Table */}
          <div className="overflow-x-auto bg-white rounded-2xl border border-slate-200 shadow-sm">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
                <tr>
                  <th className="py-3 px-3">
                    <input
                      type="checkbox"
                      checked={selectedStudentIds.length === filteredStudents.length && filteredStudents.length > 0}
                      onChange={toggleSelectAll}
                      className="rounded"
                    />
                  </th>
                  <th className="py-3 px-3">Student</th>
                  <th className="py-3 px-3">Roll No</th>
                  <th className="py-3 px-3">Dept &bull; Sem</th>
                  <th className="py-3 px-3">CGPA / Backlogs</th>
                  <th className="py-3 px-3">Attendance</th>
                  <th className="py-3 px-3">LMS %</th>
                  <th className="py-3 px-3">Coding / Apt</th>
                  <th className="py-3 px-3">Success Score</th>
                  <th className="py-3 px-3">Risk Diagnostic</th>
                  <th className="py-3 px-3">Segment</th>
                  <th className="py-3 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {paginatedStudents.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-3">
                      <input
                        type="checkbox"
                        checked={selectedStudentIds.includes(s.id)}
                        onChange={() => toggleSelectStudent(s.id)}
                        className="rounded"
                      />
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2.5">
                        <img src={s.avatar} alt="" className="w-8 h-8 rounded-full object-cover shrink-0" />
                        <div>
                          <span className="font-bold text-slate-900 block">{s.name}</span>
                          <span className="text-[10px] text-slate-400">{s.email}</span>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-600">{s.rollNo}</td>
                    <td className="py-3 px-3 text-slate-600">{s.department} &bull; Sem {s.semester}</td>
                    <td className="py-3 px-3">
                      <span className="font-bold text-slate-900">{s.cgpa.toFixed(2)}</span>
                      {s.backlogs > 0 ? (
                        <span className="ml-1.5 px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800">
                          {s.backlogs} Backlog
                        </span>
                      ) : (
                        <span className="ml-1.5 text-[10px] text-emerald-600 font-semibold">0 bl</span>
                      )}
                    </td>
                    <td className="py-3 px-3">
                      <span className={`font-bold ${s.attendance.overallPct < 75 ? 'text-rose-600' : 'text-slate-800'}`}>
                        {s.attendance.overallPct}%
                      </span>
                      {s.attendance.overallPct < 75 && (
                        <span className="block text-[9px] text-rose-600 font-bold">&lt; 75% Cliff</span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-slate-700 font-mono">{s.lms.assignmentCompletionPct}%</td>
                    <td className="py-3 px-3">
                      <span className="font-bold text-indigo-600 font-mono">{s.placement.codingScore}</span>
                      <span className="text-slate-400 mx-1">/</span>
                      <span className="text-slate-700 font-mono">{s.placement.aptitudeScore}</span>
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-1.5">
                        <span className="text-sm font-black text-slate-900 font-mono">{s.successScore}</span>
                        <div className="w-12 bg-slate-100 h-1.5 rounded-full overflow-hidden hidden sm:block">
                          <div
                            style={{ width: `${s.successScore}%` }}
                            className={`h-full ${
                              s.successScore >= 80 ? 'bg-emerald-500' :
                              s.successScore >= 65 ? 'bg-blue-500' :
                              s.successScore >= 50 ? 'bg-amber-500' : 'bg-rose-500'
                            }`}
                          ></div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${getRiskColor(s.overallRisk)}`}>
                        {s.overallRisk}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <span className="text-[11px] font-medium text-slate-700 truncate max-w-[140px] block" title={s.segment}>
                        {s.segment}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => onSelectStudent(s)}
                        className="px-2.5 py-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination Controls */}
          <div className="p-3 bg-white rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-600">
            <div className="flex items-center gap-2">
              <span>Showing <strong>{Math.min(filteredStudents.length, (currentPage - 1) * pageSize + 1)}</strong> to <strong>{Math.min(filteredStudents.length, currentPage * pageSize)}</strong> of <strong>{filteredStudents.length}</strong> students</span>
              <span className="text-slate-300">|</span>
              <div className="flex items-center gap-1.5">
                <span>Per page:</span>
                <select
                  value={pageSize}
                  onChange={(e) => {
                    setPageSize(Number(e.target.value));
                    setCurrentPage(1);
                  }}
                  className="py-1 px-2 rounded-lg border border-slate-300 bg-slate-50 font-semibold"
                >
                  <option value={10}>10</option>
                  <option value={25}>25</option>
                  <option value={50}>50</option>
                  <option value={100}>All 100</option>
                </select>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="px-3 py-1 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed font-semibold"
              >
                Previous
              </button>
              <span className="px-2 font-mono font-bold text-slate-800">
                {currentPage} / {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage >= totalPages}
                className="px-3 py-1 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed font-semibold"
              >
                Next
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 5: AI INSTITUTIONAL COUNCIL BRIEFING (GEMINI 3.8 FLASH) */}
      {activeSubTab === 'ai-briefing' && (
        <div className="p-6 rounded-2xl bg-gradient-to-br from-indigo-50 via-blue-50 to-purple-50 border border-indigo-200 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-indigo-600 text-white">
                Leadership Intelligence
              </span>
              <h2 className="text-xl font-bold text-indigo-950 mt-1 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-600" />
                Academic Council Executive AI Briefing
              </h2>
              <p className="text-xs text-indigo-900/80">
                Powered by Gemini 3.8 Flash &bull; Institutional risk synthesis and actionable policy directives
              </p>
            </div>

            <button
              onClick={fetchAiCohortBrief}
              disabled={loadingAiBrief}
              className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-md flex items-center gap-2 transition-colors disabled:opacity-50 shrink-0"
            >
              {loadingAiBrief ? (
                <>
                  <Clock className="w-3.5 h-3.5 animate-spin" /> Analyzing Batch Metrics...
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" /> Generate Council Briefing
                </>
              )}
            </button>
          </div>

          {aiBriefing ? (
            <div className="space-y-4 text-xs animate-in fade-in duration-200">
              <div className="p-4 bg-white/95 rounded-xl border border-indigo-200 shadow-sm">
                <span className="text-[10px] font-bold uppercase text-indigo-600">Executive Headline</span>
                <h3 className="text-base font-extrabold text-indigo-950 mt-0.5">{aiBriefing.headline}</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-white/95 rounded-xl border border-blue-200 shadow-sm space-y-2">
                  <span className="font-bold text-blue-900 text-xs uppercase tracking-wide block">
                    Critical Findings &amp; Observations
                  </span>
                  <ul className="space-y-1.5 text-slate-700">
                    {aiBriefing.criticalFindings?.map((item: string, i: number) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="font-bold text-blue-600">&bull;</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-4 bg-white/95 rounded-xl border border-rose-200 shadow-sm space-y-2">
                  <span className="font-bold text-rose-900 text-xs uppercase tracking-wide block">
                    Systemic Institutional Risks
                  </span>
                  <ul className="space-y-1.5 text-slate-700">
                    {aiBriefing.systemicRisks?.map((item: string, i: number) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="font-bold text-rose-600">&bull;</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="p-4 bg-white/95 rounded-xl border border-indigo-200 shadow-sm space-y-2">
                <span className="font-bold text-indigo-900 text-xs uppercase tracking-wide block">
                  Strategic Administrative Recommendations
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {aiBriefing.strategicRecommendations?.map((rec: string, i: number) => (
                    <div key={i} className="p-3 bg-indigo-50/60 rounded-lg border border-indigo-100 text-slate-800">
                      <span className="font-bold text-indigo-700 block text-[11px] mb-1">0{i + 1}. Directive</span>
                      <p>{rec}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 flex items-center justify-between text-emerald-950 font-medium">
                <span><strong>Expected Impact:</strong> {aiBriefing.expectedImpact}</span>
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              </div>
            </div>
          ) : (
            <div className="p-8 text-center bg-white/70 rounded-xl border border-dashed border-indigo-200">
              <Sparkles className="w-8 h-8 text-indigo-500 mx-auto mb-2" />
              <p className="text-sm font-bold text-indigo-950">
                Institutional Executive Summary Ready to Generate
              </p>
              <p className="text-xs text-indigo-900/70 mt-1 max-w-md mx-auto">
                Synthesizes attendance drop-offs, coding deficits, and backlog correlations into formal recommendations for the Academic Council.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
