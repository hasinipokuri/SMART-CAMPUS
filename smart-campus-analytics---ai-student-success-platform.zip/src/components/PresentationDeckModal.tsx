import React, { useState, useEffect } from 'react';
import {
  X,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  Presentation,
  CheckCircle,
  TrendingUp,
  AlertTriangle,
  Award,
  Layers,
  Sparkles,
  Users,
  Compass,
} from 'lucide-react';

interface PresentationDeckModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PresentationDeckModal: React.FC<PresentationDeckModalProps> = ({ isOpen, onClose }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [showNotes, setShowNotes] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const slides = [
    {
      id: 1,
      tag: 'Challenge & Background',
      title: 'Breaking Campus Data Silos for Student Success',
      subtitle: 'Colleges capture massive student activity, but disconnected systems create blind spots.',
      icon: Layers,
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-auto">
          <div className="p-5 rounded-2xl bg-rose-50/80 border border-rose-200">
            <h4 className="font-bold text-rose-900 text-sm uppercase tracking-wider mb-3 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-600"></span>
              The Fragmented Status Quo
            </h4>
            <ul className="space-y-3 text-xs md:text-sm text-rose-950">
              <li className="flex items-start gap-2">
                <span className="font-bold text-rose-600">&bull;</span>
                <span><strong>LMS Clickstreams:</strong> Dormant in Moodle/Canvas; assignment drops unnoticed.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold text-rose-600">&bull;</span>
                <span><strong>Biometric Attendance:</strong> Reviewed only when exam hall tickets are blocked.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold text-rose-600">&bull;</span>
                <span><strong>Placement Portal:</strong> Coding deficiencies detected during final year drives.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold text-rose-600">&bull;</span>
                <span><strong>Reactive Culture:</strong> Counselors intervene only after semester failures.</span>
              </li>
            </ul>
          </div>

          <div className="p-5 rounded-2xl bg-emerald-50/80 border border-emerald-200">
            <h4 className="font-bold text-emerald-900 text-sm uppercase tracking-wider mb-3 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
              The Smart Campus Analytics Vision
            </h4>
            <ul className="space-y-3 text-xs md:text-sm text-emerald-950">
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Unified Student Profile:</strong> Consolidating 7 distinct campus data streams.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Explainable Success Score:</strong> Transparent attribution (no opaque black box).</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Dual-Risk Engine:</strong> Decouples academic risks from placement bottlenecks.</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span><strong>Actionable Interventions:</strong> Automated remedial workflows &amp; AI coaching.</span>
              </li>
            </ul>
          </div>
        </div>
      ),
      notes: 'Presenter Note: Emphasize that universities do not suffer from a lack of student data; they suffer from data fragmentation. Our solution transforms passive records into early proactive intelligence.',
    },
    {
      id: 2,
      tag: 'Core Scope & Architecture',
      title: 'Unified 7-Source Student Intelligence Layer',
      subtitle: 'Synchronizing academic, behavioral, engagement, and industry readiness in real time.',
      icon: Users,
      content: (
        <div className="space-y-4 my-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl">
              <span className="text-[10px] font-bold uppercase text-blue-600">01. Academic</span>
              <p className="font-semibold text-blue-950 mt-1">CGPA, marks %, backlogs, course-wise grades</p>
            </div>
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl">
              <span className="text-[10px] font-bold uppercase text-amber-600">02. Attendance</span>
              <p className="font-semibold text-amber-950 mt-1">Overall %, subject-wise %, 6-week moving trend</p>
            </div>
            <div className="p-3 bg-cyan-50 border border-cyan-200 rounded-xl">
              <span className="text-[10px] font-bold uppercase text-cyan-600">03. LMS Activity</span>
              <p className="font-semibold text-cyan-950 mt-1">Weekly logins, quiz scores, assignment cadence</p>
            </div>
            <div className="p-3 bg-purple-50 border border-purple-200 rounded-xl">
              <span className="text-[10px] font-bold uppercase text-purple-600">04. Placement</span>
              <p className="font-semibold text-purple-950 mt-1">DSA coding tests, quant aptitude, mock tech/HR</p>
            </div>
            <div className="p-3 bg-pink-50 border border-pink-200 rounded-xl">
              <span className="text-[10px] font-bold uppercase text-pink-600">05. Skills Radar</span>
              <p className="font-semibold text-pink-950 mt-1">DSA, System Design, DevOps, Soft skills</p>
            </div>
            <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-xl">
              <span className="text-[10px] font-bold uppercase text-indigo-600">06. Engagement</span>
              <p className="font-semibold text-indigo-950 mt-1">Hackathons, IEEE/ACM clubs, cloud certifications</p>
            </div>
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl col-span-2">
              <span className="text-[10px] font-bold uppercase text-emerald-600">07. Feedback &amp; Mentorship</span>
              <p className="font-semibold text-emerald-950 mt-1">Student sentiment pulse, mentor counseling logs, faculty observations</p>
            </div>
          </div>
          <div className="p-3 bg-slate-900 text-slate-200 rounded-xl text-xs flex items-center justify-between">
            <span>Unified JSON Schema with deterministic sub-scoring and server-side Gemini 3.8 Flash intelligence</span>
            <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 font-mono text-[10px] rounded">Normalized 0-100</span>
          </div>
        </div>
      ),
      notes: 'Presenter Note: Highlight how easily each campus source connects into our standardized schema, giving administrators a true 360-degree view of student progress.',
    },
    {
      id: 3,
      tag: 'Mathematical Formulation',
      title: 'The Student Success Score (0–100)',
      subtitle: 'Weighted composite index calibrated with statistical weights and penalty barriers.',
      icon: TrendingUp,
      content: (
        <div className="space-y-4 my-auto">
          <div className="p-4 bg-slate-900 rounded-2xl text-white font-mono text-xs md:text-sm shadow-xl">
            <div className="text-slate-400 mb-1">// Mathematical Formulation</div>
            <span className="text-emerald-400 font-bold">SuccessScore</span> = 
            (0.30 &times; <span className="text-blue-300">Academic</span>) + 
            (0.25 &times; <span className="text-purple-300">Placement</span>) + 
            (0.20 &times; <span className="text-amber-300">Attendance</span>) + 
            (0.15 &times; <span className="text-cyan-300">LMS</span>) + 
            (0.10 &times; <span className="text-pink-300">Engagement</span>)
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="p-3 rounded-xl border border-slate-200 bg-white shadow-sm">
              <span className="font-bold text-slate-900">Backlog Penalty Function</span>
              <p className="text-slate-600 mt-1">-12 points per active backlog. Prevents students from masking standing backlogs behind high attendance or club participation.</p>
            </div>
            <div className="p-3 rounded-xl border border-slate-200 bg-white shadow-sm">
              <span className="font-bold text-slate-900">75% Statutory Attendance Cliff</span>
              <p className="text-slate-600 mt-1">Accelerated penalty slope below 75% to mirror university examination hall ticket detention regulations.</p>
            </div>
            <div className="p-3 rounded-xl border border-slate-200 bg-white shadow-sm">
              <span className="font-bold text-slate-900">LMS Early Warning Weight</span>
              <p className="text-slate-600 mt-1">Assignment submission drop-offs serve as leading indicators, triggering alerts 3 weeks before mid-term exams.</p>
            </div>
          </div>
        </div>
      ),
      notes: 'Presenter Note: Explain the rationale behind the weights: Academic + Placement account for 55% as core outcome variables, while Attendance + LMS represent leading behavioral variables.',
    },
    {
      id: 4,
      tag: 'Bonus Feature 1',
      title: 'Actionable Student Segmentation Matrix',
      subtitle: 'Behavioral 4-quadrant clustering replaces one-size-fits-all advising.',
      icon: Compass,
      content: (
        <div className="grid grid-cols-2 gap-3 text-xs my-auto">
          <div className="p-4 rounded-xl bg-indigo-50 border border-indigo-200">
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-indigo-900">Consistent High Achievers</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-200 text-indigo-900 font-bold">Top Right</span>
            </div>
            <p className="text-indigo-950/80 mb-2">High Academic (CGPA &gt; 8.3) + High Placement (Coding &gt; 75).</p>
            <span className="font-semibold text-indigo-700 block text-[11px]">&rarr; Action: Fast-track to Dream Tier-1 (Google, Amazon 25+ LPA)</span>
          </div>

          <div className="p-4 rounded-xl bg-amber-50 border border-amber-200">
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-amber-900">&ldquo;The Bookworms&rdquo;</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-amber-200 text-amber-900 font-bold">Bottom Right</span>
            </div>
            <p className="text-amber-950/80 mb-2">High CGPA (8.8+) but Low Placement Readiness (Coding &lt; 60).</p>
            <span className="font-semibold text-amber-700 block text-[11px]">&rarr; Action: DSA bootcamp, whiteboard interview drills</span>
          </div>

          <div className="p-4 rounded-xl bg-cyan-50 border border-cyan-200">
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-cyan-900">&ldquo;Hidden Prodigies&rdquo;</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-200 text-cyan-900 font-bold">Top Left</span>
            </div>
            <p className="text-cyan-950/80 mb-2">Top Coding (&gt;85, Hackathon wins) but Attendance &lt; 75% or Backlogs.</p>
            <span className="font-semibold text-cyan-700 block text-[11px]">&rarr; Action: Attendance recovery contract &amp; backlog tutoring</span>
          </div>

          <div className="p-4 rounded-xl bg-rose-50 border border-rose-200">
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-rose-900">Silent Strugglers</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-rose-200 text-rose-900 font-bold">Bottom Left</span>
            </div>
            <p className="text-rose-950/80 mb-2">Low LMS engagement, falling attendance, borderline CGPA.</p>
            <span className="font-semibold text-rose-700 block text-[11px]">&rarr; Action: 1-on-1 counseling, peer study buddy, parent meeting</span>
          </div>
        </div>
      ),
      notes: 'Presenter Note: Point out how "The Bookworm" and "Hidden Prodigy" segments solve real campus headaches: Bookworms fail recruitment interviews, while Prodigies get detained from exams despite being top coders.',
    },
    {
      id: 5,
      tag: 'Bonus Feature 2 & AI Engine',
      title: 'Explainable Scoring & Proactive Interventions',
      subtitle: 'SHAP-like waterfall driver decomposition + Gemini 3.8 Flash personalized advisory.',
      icon: Sparkles,
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs my-auto">
          <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-sm space-y-2">
            <span className="font-bold text-slate-900 text-sm block">Explainable Attribution Waterfall</span>
            <p className="text-slate-600">Students and mentors see exactly which factors contribute or detract points:</p>
            <div className="space-y-1.5 pt-1 font-mono text-[11px]">
              <div className="flex justify-between p-1.5 rounded bg-slate-100">
                <span>Baseline Score:</span>
                <span className="font-bold">50.0 pts</span>
              </div>
              <div className="flex justify-between p-1.5 rounded bg-emerald-50 text-emerald-800">
                <span>+ CGPA 8.92 (High Mastery):</span>
                <span className="font-bold">+12.5 pts</span>
              </div>
              <div className="flex justify-between p-1.5 rounded bg-emerald-50 text-emerald-800">
                <span>+ Clean Record (0 Backlogs):</span>
                <span className="font-bold">+6.0 pts</span>
              </div>
              <div className="flex justify-between p-1.5 rounded bg-rose-50 text-rose-800">
                <span>- Low Coding Assessment (48/100):</span>
                <span className="font-bold">-8.5 pts</span>
              </div>
              <div className="flex justify-between p-1.5 rounded bg-rose-50 text-rose-800">
                <span>- Weak Mock Tech Interview (2.4/5):</span>
                <span className="font-bold">-5.2 pts</span>
              </div>
              <div className="flex justify-between p-1.5 rounded bg-slate-900 text-white font-bold">
                <span>Final Student Success Score:</span>
                <span>72 / 100</span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-gradient-to-br from-indigo-50 to-blue-50 border border-indigo-200 shadow-sm space-y-2">
            <span className="font-bold text-indigo-950 text-sm flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              AI Decision Intelligence (Gemini 3.8 Flash)
            </span>
            <p className="text-indigo-900/80">Generates hyper-personalized interventions tailored to individual blockers:</p>
            <ul className="space-y-2 text-indigo-950 pt-1">
              <li className="p-2 bg-white/80 rounded-lg border border-indigo-100">
                <strong>Targeted 30-Day Roadmap:</strong> Prioritizes exact technical skills needed for target job tiers.
              </li>
              <li className="p-2 bg-white/80 rounded-lg border border-indigo-100">
                <strong>Institutional Briefing:</strong> Synthesizes batch-wide risks into actionable Academic Council policies.
              </li>
              <li className="p-2 bg-white/80 rounded-lg border border-indigo-100">
                <strong>Closed-Loop Tracking:</strong> Logs interventions (Bootcamp, Tutoring, Warning) with measurable milestone resolution.
              </li>
            </ul>
          </div>
        </div>
      ),
      notes: 'Presenter Note: Emphasize that students love explainability because it tells them exactly what to fix instead of punishing them with a mysterious black-box rank.',
    },
    {
      id: 6,
      tag: 'Impact & Evaluation',
      title: 'Measurable Campus Impact & Deliverables',
      subtitle: 'Complete working platform built to exceed all 100 evaluation points and bonus credits.',
      icon: Award,
      content: (
        <div className="space-y-4 my-auto">
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200">
              <span className="text-2xl font-black text-emerald-700">88%</span>
              <p className="text-xs font-semibold text-emerald-950 mt-1">Earlier At-Risk Detection</p>
              <p className="text-[10px] text-emerald-800">4 weeks before exams</p>
            </div>
            <div className="p-4 bg-blue-50 rounded-2xl border border-blue-200">
              <span className="text-2xl font-black text-blue-700">+24%</span>
              <p className="text-xs font-semibold text-blue-950 mt-1">Day-1 Placement Clearance</p>
              <p className="text-[10px] text-blue-800">Via targeted coding bootcamps</p>
            </div>
            <div className="p-4 bg-purple-50 rounded-2xl border border-purple-200">
              <span className="text-2xl font-black text-purple-700">-65%</span>
              <p className="text-xs font-semibold text-purple-950 mt-1">Attendance Detentions</p>
              <p className="text-[10px] text-purple-800">Through early counselor nudges</p>
            </div>
          </div>

          <div className="p-4 bg-slate-900 text-white rounded-2xl text-xs space-y-2">
            <span className="font-bold text-amber-400 uppercase tracking-wider text-[10px]">Evaluation Checklist Met:</span>
            <div className="grid grid-cols-2 gap-2 text-slate-300">
              <div className="flex items-center gap-1.5"><CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> Data Integration (30 pts)</div>
              <div className="flex items-center gap-1.5"><CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> Success Score &amp; Risk ID (25 pts)</div>
              <div className="flex items-center gap-1.5"><CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> Interactive Dashboard (25 pts)</div>
              <div className="flex items-center gap-1.5"><CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> Problem Understanding (10 pts)</div>
              <div className="flex items-center gap-1.5"><CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> Presentation &amp; Slides (10 pts)</div>
              <div className="flex items-center gap-1.5"><CheckCircle className="w-3.5 h-3.5 text-amber-400" /> Bonus: Student Segmentation &amp; Explainability</div>
            </div>
          </div>
        </div>
      ),
      notes: 'Presenter Note: Conclude by offering to walk the judges through the live interactive prototype, showing both the Faculty Admin view and the Student Portal.',
    },
  ];

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === ' ') {
        setCurrentSlide((prev) => Math.min(slides.length - 1, prev + 1));
      } else if (e.key === 'ArrowLeft') {
        setCurrentSlide((prev) => Math.max(0, prev - 1));
      } else if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, slides.length, onClose]);

  if (!isOpen) return null;

  const slide = slides[currentSlide];
  const Icon = slide.icon;

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center ${isFullscreen ? 'p-0' : 'p-4'} bg-slate-950/85 backdrop-blur-md overflow-hidden transition-all duration-300`}>
      <div className={`relative flex flex-col bg-slate-900 rounded-2xl shadow-2xl border border-slate-800 text-white overflow-hidden transition-all duration-300 ${
        isFullscreen ? 'w-full h-full rounded-none' : 'w-full max-w-5xl h-[88vh] max-h-[750px]'
      }`}>
        {/* Deck Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-indigo-600/30 text-indigo-400 border border-indigo-500/30">
              <Presentation className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-semibold text-indigo-400 uppercase tracking-widest">Interactive Pitch Deck</span>
              <h2 className="text-sm font-bold text-white">Smart Campus Analytics Presentation</h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowNotes(!showNotes)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                showNotes ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white'
              }`}
            >
              Speaker Notes
            </button>
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 rounded-lg bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-colors"
              title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Slide Canvas */}
        <div className="flex-1 flex flex-col p-6 md:p-10 bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 overflow-y-auto">
          {/* Slide Header */}
          <div className="mb-4 shrink-0">
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
                {slide.tag}
              </span>
              <span className="text-xs text-slate-400 font-mono">Slide {slide.id} of {slides.length}</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
              <Icon className="w-7 h-7 text-indigo-400 shrink-0" />
              {slide.title}
            </h1>
            <p className="text-xs md:text-sm text-slate-400 mt-1">{slide.subtitle}</p>
          </div>

          {/* Slide Interactive Content */}
          <div className="flex-1 flex flex-col justify-center">
            {slide.content}
          </div>

          {/* Speaker Notes Drawer (Collapsible) */}
          {showNotes && (
            <div className="mt-4 p-3 rounded-xl bg-slate-800/80 border border-slate-700 text-xs text-amber-200 shrink-0 animate-in fade-in duration-150">
              <strong className="text-amber-400">Speaker Script: </strong>
              {slide.notes}
            </div>
          )}
        </div>

        {/* Deck Navigation Controls */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-t border-slate-800 shrink-0">
          {/* Thumbnails indicator */}
          <div className="flex items-center gap-2">
            {slides.map((s, idx) => (
              <button
                key={s.id}
                onClick={() => setCurrentSlide(idx)}
                className={`w-7 h-7 rounded-lg text-xs font-bold transition-all ${
                  currentSlide === idx
                    ? 'bg-indigo-600 text-white ring-2 ring-indigo-400 ring-offset-2 ring-offset-slate-950 scale-105'
                    : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
                }`}
              >
                {s.id}
              </button>
            ))}
          </div>

          {/* Prev / Next controls */}
          <div className="flex items-center gap-3">
            <span className="text-xs text-slate-500 hidden sm:inline">Use &larr; &rarr; arrow keys to navigate</span>
            <button
              onClick={() => setCurrentSlide((prev) => Math.max(0, prev - 1))}
              disabled={currentSlide === 0}
              className="flex items-center gap-1 px-4 py-2 text-xs font-semibold rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronLeft className="w-4 h-4" /> Previous
            </button>
            <button
              onClick={() => setCurrentSlide((prev) => Math.min(slides.length - 1, prev + 1))}
              disabled={currentSlide === slides.length - 1}
              className="flex items-center gap-1 px-4 py-2 text-xs font-semibold rounded-lg bg-indigo-600 text-white hover:bg-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              Next <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
