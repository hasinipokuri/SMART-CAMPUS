import React, { useState } from 'react';
import {
  GraduationCap,
  Users,
  Briefcase,
  Presentation,
  BookOpen,
  Sparkles,
  CheckCircle,
  RefreshCw,
  Award,
} from 'lucide-react';
import { Student, Intervention } from './types/student';
import { INITIAL_STUDENTS, buildFullStudent } from './data/mockStudents';
import { FacultyDashboard } from './components/FacultyDashboard';
import { StudentPortal } from './components/StudentPortal';
import { PlacementOfficerPortal } from './components/PlacementOfficerPortal';
import { StudentDetailModal } from './components/StudentDetailModal';
import { MethodologyModal } from './components/MethodologyModal';
import { PresentationDeckModal } from './components/PresentationDeckModal';

export default function App() {
  const [students, setStudents] = useState<Student[]>(INITIAL_STUDENTS);
  const [activeRole, setActiveRole] = useState<'faculty' | 'student' | 'placement'>('faculty');
  const [currentStudentId, setCurrentStudentId] = useState<string>(INITIAL_STUDENTS[0].id);

  // Modals state
  const [selectedStudentForDetail, setSelectedStudentForDetail] = useState<Student | null>(null);
  const [isMethodologyOpen, setIsMethodologyOpen] = useState(false);
  const [isPresentationOpen, setIsPresentationOpen] = useState(false);

  // Toast notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Add intervention to a specific student
  const handleAddIntervention = (studentId: string, intervention: Omit<Intervention, 'id'>) => {
    setStudents((prev) =>
      prev.map((s) => {
        if (s.id !== studentId) return s;
        const newInt: Intervention = {
          ...intervention,
          id: `INT-${Date.now().toString().slice(-4)}`,
        };
        const updated = {
          ...s,
          interventions: [newInt, ...s.interventions],
        };
        return buildFullStudent(updated);
      })
    );
    showToast(`Intervention assigned successfully to student.`);
  };

  // Update status of an existing intervention
  const handleUpdateInterventionStatus = (
    studentId: string,
    interventionId: string,
    status: 'pending' | 'in-progress' | 'resolved'
  ) => {
    setStudents((prev) =>
      prev.map((s) => {
        if (s.id !== studentId) return s;
        const updatedInts = s.interventions.map((int) =>
          int.id === interventionId ? { ...int, status } : int
        );
        return buildFullStudent({ ...s, interventions: updatedInts });
      })
    );
    showToast(`Intervention status updated to ${status}.`);
  };

  // Batch intervention handler
  const handleBatchIntervention = (type: string, title: string, studentIds: string[]) => {
    if (studentIds.length === 0) return;
    setStudents((prev) =>
      prev.map((s) => {
        if (!studentIds.includes(s.id)) return s;
        const newInt: Intervention = {
          id: `INT-${Date.now().toString().slice(-4)}-${s.id}`,
          type: type as any,
          title,
          assignedBy: 'Campus Council',
          assignedDate: new Date().toISOString().split('T')[0],
          targetDate: new Date(Date.now() + 21 * 86400000).toISOString().split('T')[0],
          status: 'in-progress',
          notes: 'Batch assigned via Smart Campus Success platform.',
        };
        return buildFullStudent({ ...s, interventions: [newInt, ...s.interventions] });
      })
    );
    showToast(`Batch intervention triggered for ${studentIds.length} student(s).`);
  };

  // Reset to sample cohort
  const handleResetCohort = () => {
    setStudents(INITIAL_STUDENTS);
    showToast('Cohort data reset to benchmark dataset.');
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 font-sans flex flex-col antialiased selection:bg-indigo-500 selection:text-white">
      {/* Toast Banner */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 flex items-center gap-2 px-4 py-3 bg-slate-900 text-white text-xs font-semibold rounded-xl shadow-2xl border border-slate-700 animate-in fade-in slide-in-from-top-4 duration-200">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Application Navbar */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          {/* Logo & Branding */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-600 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-slate-900 text-base tracking-tight">Smart Campus Analytics</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-700 font-mono hidden sm:inline">
                  AI-Powered
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium hidden md:block">
                Predict, Optimize &amp; Improve Student Success
              </p>
            </div>
          </div>

          {/* Central Role Selector Pills */}
          <nav className="flex items-center p-1 bg-slate-100 rounded-xl border border-slate-200/80 text-xs font-semibold">
            <button
              onClick={() => setActiveRole('faculty')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg transition-all ${
                activeRole === 'faculty'
                  ? 'bg-white text-indigo-700 shadow-sm font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Faculty &amp; Admin</span>
            </button>

            <button
              onClick={() => setActiveRole('student')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg transition-all ${
                activeRole === 'student'
                  ? 'bg-white text-indigo-700 shadow-sm font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5" />
              <span>Student Portal</span>
            </button>

            <button
              onClick={() => setActiveRole('placement')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg transition-all ${
                activeRole === 'placement'
                  ? 'bg-white text-indigo-700 shadow-sm font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Briefcase className="w-3.5 h-3.5" />
              <span>Placement Cell</span>
            </button>
          </nav>

          {/* Right Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsPresentationOpen(true)}
              className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-xs font-bold transition-colors"
              title="Deliverable 3: Demo & Slide Deck"
            >
              <Presentation className="w-3.5 h-3.5" />
              <span>Demo Slides</span>
            </button>

            <button
              onClick={() => setIsMethodologyOpen(true)}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 text-xs font-semibold transition-colors"
              title="Deliverable 2: Scoring Formula & Indicators Note"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Methodology</span>
            </button>

            <button
              onClick={handleResetCohort}
              className="p-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors"
              title="Reset Sample Data"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* VIEW 1: FACULTY & ADMINISTRATOR DASHBOARD */}
        {activeRole === 'faculty' && (
          <FacultyDashboard
            students={students}
            onSelectStudent={(student) => setSelectedStudentForDetail(student)}
            onBatchIntervention={handleBatchIntervention}
            onOpenMethodology={() => setIsMethodologyOpen(true)}
            onOpenPresentation={() => setIsPresentationOpen(true)}
          />
        )}

        {/* VIEW 2: STUDENT PORTAL ("MY SUCCESS HUB") */}
        {activeRole === 'student' && (
          <StudentPortal
            students={students}
            currentStudentId={currentStudentId}
            onSelectStudentId={(id) => setCurrentStudentId(id)}
            onOpenMethodology={() => setIsMethodologyOpen(true)}
          />
        )}

        {/* VIEW 3: PLACEMENT OFFICER PORTAL */}
        {activeRole === 'placement' && (
          <PlacementOfficerPortal
            students={students}
            onSelectStudent={(student) => setSelectedStudentForDetail(student)}
            onBatchIntervention={handleBatchIntervention}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="mt-auto py-6 bg-white border-t border-slate-200 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-700">Smart Campus Analytics</span>
            <span>&bull;</span>
            <span>AI Student Success &amp; Early Intervention Platform</span>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsMethodologyOpen(true)}
              className="text-indigo-600 hover:underline font-semibold"
            >
              Formula &amp; Indicators Note (Deliverable 2)
            </button>
            <span>&bull;</span>
            <button
              onClick={() => setIsPresentationOpen(true)}
              className="text-indigo-600 hover:underline font-semibold"
            >
              Interactive Pitch Deck (Deliverable 3)
            </button>
          </div>
        </div>
      </footer>

      {/* MODAL 1: STUDENT 360-DEGREE DETAIL & EXPLAINABLE SCORE */}
      {selectedStudentForDetail && (
        <StudentDetailModal
          student={selectedStudentForDetail}
          isOpen={!!selectedStudentForDetail}
          onClose={() => setSelectedStudentForDetail(null)}
          onAddIntervention={handleAddIntervention}
          onUpdateInterventionStatus={handleUpdateInterventionStatus}
        />
      )}

      {/* MODAL 2: METHODOLOGY & WHITE-PAPER NOTE (DELIVERABLE 2) */}
      <MethodologyModal
        isOpen={isMethodologyOpen}
        onClose={() => setIsMethodologyOpen(false)}
      />

      {/* MODAL 3: PRESENTATION & DEMO SLIDES (DELIVERABLE 3) */}
      <PresentationDeckModal
        isOpen={isPresentationOpen}
        onClose={() => setIsPresentationOpen(false)}
      />
    </div>
  );
}
