import {
  Student,
  CohortStats,
  RiskLevel,
  StudentSegment,
  ScoreFactor,
  TargetJobRole,
} from '../types/student';

/**
 * Weights for the Student Success Score (Sum = 1.00):
 * - Academic Performance: 30% (CGPA, marks, backlog penalty)
 * - Placement Readiness: 25% (Coding, aptitude, mock interviews)
 * - Attendance & Regularity: 20% (Overall %, lab consistency, trend)
 * - LMS & Learning Engagement: 15% (Assignment completion, weekly logins)
 * - Skills & Extracurriculars: 10% (Technical/soft skills, hackathons, certs)
 */
export const SCORE_WEIGHTS = {
  ACADEMIC: 0.30,
  PLACEMENT: 0.25,
  ATTENDANCE: 0.20,
  LMS: 0.15,
  ENGAGEMENT: 0.10,
};

export const TARGET_JOB_ROLES: TargetJobRole[] = [
  {
    role: 'Software Development Engineer (SDE-1)',
    tier: 'Dream (25+ LPA)',
    minCgpa: 8.0,
    minCoding: 85,
    minAptitude: 80,
    skillsRequired: [
      { name: 'Data Structures & Algorithms', minScore: 85 },
      { name: 'System Design & Architecture', minScore: 70 },
      { name: 'Databases & SQL', minScore: 80 },
      { name: 'Problem Solving', minScore: 85 },
      { name: 'Communication', minScore: 75 },
    ],
  },
  {
    role: 'Full Stack Web Engineer',
    tier: 'Tier-1 (10-25 LPA)',
    minCgpa: 7.2,
    minCoding: 75,
    minAptitude: 70,
    skillsRequired: [
      { name: 'Web & API Development', minScore: 80 },
      { name: 'Data Structures & Algorithms', minScore: 70 },
      { name: 'Databases & SQL', minScore: 75 },
      { name: 'Cloud & DevOps Basics', minScore: 65 },
      { name: 'Teamwork', minScore: 75 },
    ],
  },
  {
    role: 'AI / Machine Learning Engineer',
    tier: 'Dream (25+ LPA)',
    minCgpa: 8.2,
    minCoding: 80,
    minAptitude: 85,
    skillsRequired: [
      { name: 'Machine Learning & Math', minScore: 85 },
      { name: 'Python & Data Engineering', minScore: 80 },
      { name: 'Data Structures & Algorithms', minScore: 75 },
      { name: 'Problem Solving', minScore: 80 },
    ],
  },
  {
    role: 'Cloud & DevOps Specialist',
    tier: 'Tier-1 (10-25 LPA)',
    minCgpa: 7.0,
    minCoding: 70,
    minAptitude: 70,
    skillsRequired: [
      { name: 'Cloud & DevOps Basics', minScore: 85 },
      { name: 'Databases & SQL', minScore: 75 },
      { name: 'Computer Networks', minScore: 80 },
      { name: 'System Design & Architecture', minScore: 65 },
    ],
  },
  {
    role: 'Associate Software Engineer / Core',
    tier: 'Core Tech (5-10 LPA)',
    minCgpa: 6.5,
    minCoding: 60,
    minAptitude: 60,
    skillsRequired: [
      { name: 'Data Structures & Algorithms', minScore: 60 },
      { name: 'Databases & SQL', minScore: 60 },
      { name: 'Problem Solving', minScore: 65 },
      { name: 'Communication', minScore: 65 },
    ],
  },
];

export function calculateSubScores(student: Partial<Student>) {
  // 1. Academic subscore (0-100)
  const cgpaNormalized = ((student.cgpa || 7.0) / 10) * 100;
  const marksComponent = student.marksPct || cgpaNormalized;
  const backlogPenalty = (student.backlogs || 0) * 15;
  const academicScore = Math.max(0, Math.min(100, Math.round(
    cgpaNormalized * 0.75 + marksComponent * 0.25 - backlogPenalty
  )));

  // 2. Placement subscore (0-100)
  const coding = student.placement?.codingScore || 50;
  const aptitude = student.placement?.aptitudeScore || 50;
  const mockTech = ((student.placement?.mockTechRating || 3) / 5) * 100;
  const mockHr = ((student.placement?.mockHrRating || 3) / 5) * 100;
  const placementScore = Math.round(
    coding * 0.40 + aptitude * 0.30 + mockTech * 0.20 + mockHr * 0.10
  );

  // 3. Attendance subscore (0-100)
  const attPct = student.attendance?.overallPct || 75;
  let attendanceScore = attPct;
  // Penalty if below mandatory statutory limit of 75%
  if (attPct < 75) {
    attendanceScore = Math.max(0, attPct - (75 - attPct) * 0.8);
  }
  attendanceScore = Math.round(attendanceScore);

  // 4. LMS subscore (0-100)
  const lmsCompletion = student.lms?.assignmentCompletionPct || 70;
  const lmsLogins = Math.min(100, ((student.lms?.weeklyLogins || 5) / 10) * 100);
  const lmsScore = Math.round(lmsCompletion * 0.70 + lmsLogins * 0.30);

  // 5. Engagement subscore (0-100)
  const certCount = student.engagement?.certifications?.length || 0;
  const hackathons = student.engagement?.hackathons || 0;
  const softSkillsAvg = student.skills
    ? student.skills.filter((s) => s.category === 'soft').reduce((acc, s) => acc + s.currentScore, 0) /
      Math.max(1, student.skills.filter((s) => s.category === 'soft').length)
    : 70;
  const engagementScore = Math.min(
    100,
    Math.round(softSkillsAvg * 0.50 + Math.min(25, certCount * 12.5) + Math.min(25, hackathons * 12.5))
  );

  // Composite Success Score
  const successScore = Math.round(
    academicScore * SCORE_WEIGHTS.ACADEMIC +
    placementScore * SCORE_WEIGHTS.PLACEMENT +
    attendanceScore * SCORE_WEIGHTS.ATTENDANCE +
    lmsScore * SCORE_WEIGHTS.LMS +
    engagementScore * SCORE_WEIGHTS.ENGAGEMENT
  );

  return {
    academicScore,
    placementScore,
    attendanceScore,
    lmsScore,
    engagementScore,
    successScore: Math.max(1, Math.min(99, successScore)),
  };
}

export function determineRisks(student: Partial<Student>): {
  academicRisk: RiskLevel;
  placementRisk: RiskLevel;
  overallRisk: RiskLevel;
} {
  const cgpa = student.cgpa || 7.0;
  const backlogs = student.backlogs || 0;
  const attendance = student.attendance?.overallPct || 75;
  const lms = student.lms?.assignmentCompletionPct || 70;

  const coding = student.placement?.codingScore || 60;
  const aptitude = student.placement?.aptitudeScore || 60;
  const mockTech = student.placement?.mockTechRating || 3.0;

  // Academic Risk
  let academicRisk: RiskLevel = 'Low';
  if (backlogs >= 2 || attendance < 65 || cgpa < 5.8) {
    academicRisk = 'Critical';
  } else if (backlogs >= 1 || attendance < 75 || cgpa < 6.8) {
    academicRisk = 'High';
  } else if (attendance < 80 || cgpa < 7.4 || lms < 68) {
    academicRisk = 'Moderate';
  }

  // Placement Risk
  let placementRisk: RiskLevel = 'Low';
  if (coding < 45 || aptitude < 45 || (student.semester && student.semester >= 6 && backlogs > 0)) {
    placementRisk = 'Critical';
  } else if (coding < 60 || aptitude < 55 || mockTech < 2.5) {
    placementRisk = 'High';
  } else if (coding < 72 || aptitude < 68 || mockTech < 3.5) {
    placementRisk = 'Moderate';
  }

  // Overall Risk
  let overallRisk: RiskLevel = 'Low';
  if (academicRisk === 'Critical' || placementRisk === 'Critical') {
    overallRisk = 'Critical';
  } else if (academicRisk === 'High' || placementRisk === 'High') {
    overallRisk = 'High';
  } else if (academicRisk === 'Moderate' || placementRisk === 'Moderate') {
    overallRisk = 'Moderate';
  }

  return { academicRisk, placementRisk, overallRisk };
}

export function determineSegment(
  student: Partial<Student>,
  academicScore: number,
  placementScore: number
): StudentSegment {
  const cgpa = student.cgpa || 7.0;
  const coding = student.placement?.codingScore || 60;
  const att = student.attendance?.overallPct || 75;
  const lms = student.lms?.assignmentCompletionPct || 70;

  // 1. Consistent High Achievers (Top performers in both)
  if (cgpa >= 8.3 && coding >= 75 && att >= 80) {
    return 'Consistent High Achievers';
  }

  // 2. High Academics - Low Placement ("The Bookworms")
  if (cgpa >= 7.8 && coding < 64) {
    return 'High Academics - Low Placement';
  }

  // 3. High Placement - Academic/Attendance At-Risk ("Hidden Prodigies")
  if (coding >= 76 && (cgpa < 7.2 || att < 75)) {
    return 'High Placement - Academic/Attendance At-Risk';
  }

  // 4. Silent Strugglers / Disengaged
  if (cgpa < 6.7 && att < 72 && lms < 65) {
    return 'Silent Strugglers / Disengaged';
  }

  // 5. Well-Rounded Core (Steady solid performers)
  return 'Well-Rounded Core';
}

export function generateExplainableFactors(student: Partial<Student>): ScoreFactor[] {
  const factors: ScoreFactor[] = [];
  const cgpa = student.cgpa || 7.0;
  const backlogs = student.backlogs || 0;
  const att = student.attendance?.overallPct || 75;
  const coding = student.placement?.codingScore || 60;
  const aptitude = student.placement?.aptitudeScore || 60;
  const lms = student.lms?.assignmentCompletionPct || 70;
  const certs = student.engagement?.certifications?.length || 0;
  const hackathons = student.engagement?.hackathons || 0;

  // CGPA Factor
  const cgpaDiff = cgpa - 7.0;
  const cgpaImpact = Math.round(cgpaDiff * 6.5);
  factors.push({
    factor: 'Academic Standing (CGPA)',
    category: 'Academic',
    impactPoints: cgpaImpact,
    valueDisplay: `${cgpa.toFixed(2)} / 10.0`,
    benchmark: 'Campus Avg: 7.20',
    insight: cgpa >= 8.5 ? 'Excellent foundational mastery' : cgpa < 6.5 ? 'Sub-par grades; risks degree classification' : 'Good steady performance',
    isPositive: cgpaImpact >= 0,
  });

  // Backlogs
  if (backlogs > 0) {
    factors.push({
      factor: 'Active Backlog Penalty',
      category: 'Academic',
      impactPoints: -backlogs * 12,
      valueDisplay: `${backlogs} Course(s)`,
      benchmark: '0 Backlogs required for 85% placements',
      insight: `Immediate detention trigger for campus interviews`,
      isPositive: false,
    });
  } else {
    factors.push({
      factor: 'Clean Academic Record',
      category: 'Academic',
      impactPoints: +6,
      valueDisplay: '0 Backlogs',
      benchmark: 'Clear History',
      insight: 'Full eligibility across all tier-1 campus drives',
      isPositive: true,
    });
  }

  // Attendance
  const attDiff = att - 75;
  const attImpact = Math.round(attDiff * 0.6);
  factors.push({
    factor: 'Classroom & Lab Attendance',
    category: 'Attendance',
    impactPoints: attImpact,
    valueDisplay: `${att}%`,
    benchmark: 'Statutory threshold: 75%',
    insight: att < 75 ? 'Critical exam hall ticket detention warning' : att >= 88 ? 'Exemplary presence and classroom engagement' : 'Satisfies basic university attendance requirements',
    isPositive: attImpact >= 0,
  });

  // Coding Proficiency
  const codingDiff = coding - 60;
  const codingImpact = Math.round(codingDiff * 0.35);
  factors.push({
    factor: 'Technical Coding Assessment',
    category: 'Placement',
    impactPoints: codingImpact,
    valueDisplay: `${coding} / 100`,
    benchmark: 'Tier-1 Cutoff: 75/100',
    insight: coding >= 80 ? 'Competitive candidate for SDE-1 roles' : coding < 55 ? 'Severe gap in DSA, Trees, and DP' : 'Standard proficiency for core IT roles',
    isPositive: codingImpact >= 0,
  });

  // Aptitude
  const aptDiff = aptitude - 60;
  const aptImpact = Math.round(aptDiff * 0.25);
  factors.push({
    factor: 'Quantitative & Logical Aptitude',
    category: 'Placement',
    impactPoints: aptImpact,
    valueDisplay: `${aptitude} / 100`,
    benchmark: 'Aptitude Cutoff: 65/100',
    insight: aptitude >= 80 ? 'Strong analytical reasoning' : aptitude < 50 ? 'Likely to fail Round-1 screening' : 'Satisfactory test readiness',
    isPositive: aptImpact >= 0,
  });

  // LMS Engagement
  const lmsDiff = lms - 70;
  const lmsImpact = Math.round(lmsDiff * 0.2);
  factors.push({
    factor: 'LMS Assignment & Quiz Cadence',
    category: 'LMS',
    impactPoints: lmsImpact,
    valueDisplay: `${lms}% completed`,
    benchmark: 'Department Avg: 78%',
    insight: lms < 60 ? 'Chronic assignment submission delays' : 'Disciplined weekly submissions',
    isPositive: lmsImpact >= 0,
  });

  // Extracurricular & Credentials
  if (certs > 0 || hackathons > 0) {
    const credImpact = Math.min(10, certs * 3 + hackathons * 4);
    factors.push({
      factor: 'Industry Credentials & Hackathons',
      category: 'Engagement',
      impactPoints: credImpact,
      valueDisplay: `${certs} Certs, ${hackathons} Hackathons`,
      benchmark: 'Strong resume differentiator',
      insight: 'Signals proactive initiative and practical application',
      isPositive: true,
    });
  }

  // Sort by absolute impact magnitude descending
  return factors.sort((a, b) => Math.abs(b.impactPoints) - Math.abs(a.impactPoints));
}

export function computeCohortStats(students: Student[]): CohortStats {
  if (students.length === 0) {
    return {
      totalStudents: 0,
      avgSuccessScore: 0,
      avgCgpa: 0,
      avgAttendance: 0,
      avgCodingScore: 0,
      avgAptitudeScore: 0,
      avgLmsCompletion: 0,
      academicAtRiskCount: 0,
      academicAtRiskPct: 0,
      placementAtRiskCount: 0,
      placementAtRiskPct: 0,
      criticalInterventionCount: 0,
      segmentDistribution: {
        'Consistent High Achievers': 0,
        'High Academics - Low Placement': 0,
        'High Placement - Academic/Attendance At-Risk': 0,
        'Silent Strugglers / Disengaged': 0,
        'Well-Rounded Core': 0,
      },
      deptSummary: {},
    };
  }

  const count = students.length;
  const sumSuccess = students.reduce((sum, s) => sum + s.successScore, 0);
  const sumCgpa = students.reduce((sum, s) => sum + s.cgpa, 0);
  const sumAtt = students.reduce((sum, s) => sum + s.attendance.overallPct, 0);
  const sumCoding = students.reduce((sum, s) => sum + s.placement.codingScore, 0);
  const sumAptitude = students.reduce((sum, s) => sum + s.placement.aptitudeScore, 0);
  const sumLms = students.reduce((sum, s) => sum + s.lms.assignmentCompletionPct, 0);

  const academicAtRisk = students.filter((s) => s.academicRisk === 'High' || s.academicRisk === 'Critical').length;
  const placementAtRisk = students.filter((s) => s.placementRisk === 'High' || s.placementRisk === 'Critical').length;
  const criticalIntervention = students.filter((s) => s.overallRisk === 'Critical').length;

  const segmentCounts: Record<StudentSegment, number> = {
    'Consistent High Achievers': 0,
    'High Academics - Low Placement': 0,
    'High Placement - Academic/Attendance At-Risk': 0,
    'Silent Strugglers / Disengaged': 0,
    'Well-Rounded Core': 0,
  };

  const deptMap: Record<string, { count: number; totalSuccess: number; atRisk: number }> = {};

  students.forEach((s) => {
    segmentCounts[s.segment] = (segmentCounts[s.segment] || 0) + 1;

    if (!deptMap[s.department]) {
      deptMap[s.department] = { count: 0, totalSuccess: 0, atRisk: 0 };
    }
    deptMap[s.department].count += 1;
    deptMap[s.department].totalSuccess += s.successScore;
    if (s.overallRisk === 'High' || s.overallRisk === 'Critical') {
      deptMap[s.department].atRisk += 1;
    }
  });

  const deptSummary: Record<string, { count: number; avgSuccess: number; atRiskPct: number }> = {};
  Object.keys(deptMap).forEach((dept) => {
    const d = deptMap[dept];
    deptSummary[dept] = {
      count: d.count,
      avgSuccess: Math.round(d.totalSuccess / d.count),
      atRiskPct: Math.round((d.atRisk / d.count) * 100),
    };
  });

  return {
    totalStudents: count,
    avgSuccessScore: Math.round(sumSuccess / count),
    avgCgpa: +(sumCgpa / count).toFixed(2),
    avgAttendance: Math.round(sumAtt / count),
    avgCodingScore: Math.round(sumCoding / count),
    avgAptitudeScore: Math.round(sumAptitude / count),
    avgLmsCompletion: Math.round(sumLms / count),
    academicAtRiskCount: academicAtRisk,
    academicAtRiskPct: Math.round((academicAtRisk / count) * 100),
    placementAtRiskCount: placementAtRisk,
    placementAtRiskPct: Math.round((placementAtRisk / count) * 100),
    criticalInterventionCount: criticalIntervention,
    segmentDistribution: segmentCounts,
    deptSummary,
  };
}
