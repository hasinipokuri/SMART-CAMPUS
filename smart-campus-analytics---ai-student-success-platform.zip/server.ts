import express from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Initialize Gemini API client if API key is present
const apiKey = process.env.GEMINI_API_KEY || '';
let aiClient: GoogleGenAI | null = null;
if (apiKey) {
  aiClient = new GoogleGenAI({ apiKey });
}

// AI Endpoint: Personalized Student Success & Intervention Advisor
app.post('/api/ai/student-advice', async (req, res) => {
  try {
    const { student, targetCompanyTier } = req.body;
    if (!student) {
      return res.status(400).json({ error: 'Student data is required' });
    }

    if (!aiClient) {
      // Deterministic high-quality fallback if no API key is provided
      return res.json({
        source: 'local-analytics-engine',
        advice: generateDeterministicStudentAdvice(student, targetCompanyTier),
      });
    }

    const prompt = `You are a Senior Academic Dean and Placement Director analyzing a student's profile in a Smart Campus Success Analytics Platform.
Student Profile:
- Name: ${student.name} (${student.rollNo}), Dept: ${student.department}, Sem: ${student.semester}
- CGPA: ${student.cgpa}/10, Active Backlogs: ${student.backlogs}
- Attendance: ${student.attendance}% (Trend: ${student.attendanceTrend})
- LMS Assignment Completion: ${student.lmsCompletion}%, LMS Weekly Logins: ${student.lmsLogins}
- Placement Coding Score: ${student.codingScore}/100, Aptitude Score: ${student.aptitudeScore}/100
- Mock Interview: ${student.mockInterviewRating}/5.0
- Extracurricular & Certifications: ${student.certifications.join(', ')} | Hackathons: ${student.hackathons}
- Overall Success Score: ${student.successScore}/100
- Risk Status: Academic Risk: ${student.academicRisk}, Placement Risk: ${student.placementRisk}
- Target Goal: ${targetCompanyTier || 'Tier-1 Tech Companies'}

Provide a structured, highly actionable response with the following sections in JSON:
{
  "summary": "2-sentence executive diagnosis of the student's standing and trajectory",
  "rootCauses": ["3 key underlying bottleneck factors holding them back or placing them at risk"],
  "academicActionPlan": ["2 concrete actions for faculty/student to improve CGPA or attendance"],
  "placementActionPlan": ["3 prioritized technical & soft skills to acquire in the next 30 days"],
  "recommendedIntervention": "Specific institutional intervention (e.g. Peer Tutoring, Coding Bootcamp, Counseling, Faculty Mentorship)",
  "encouragementQuote": "A brief empowering quote tailored to their strengths"
}
Return valid raw JSON only without markdown formatting.`;

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = generateDeterministicStudentAdvice(student, targetCompanyTier);
    }

    return res.json({
      source: 'gemini-3.8-flash',
      advice: parsed,
    });
  } catch (error: any) {
    console.error('Error generating AI student advice:', error);
    // Return high quality fallback on error
    const fallback = generateDeterministicStudentAdvice(req.body?.student, req.body?.targetCompanyTier);
    return res.json({
      source: 'fallback-engine',
      advice: fallback,
      errorNote: error.message || 'Gemini service unreachable',
    });
  }
});

// AI Endpoint: Cohort Executive Summary for College Administrators
app.post('/api/ai/cohort-summary', async (req, res) => {
  try {
    const { cohortStats } = req.body;
    if (!cohortStats) {
      return res.status(400).json({ error: 'Cohort statistics required' });
    }

    if (!aiClient) {
      return res.json({
        source: 'local-analytics-engine',
        summary: generateDeterministicCohortSummary(cohortStats),
      });
    }

    const prompt = `You are a Higher Education Academic Analytics Specialist advising college deans and department heads.
Analyze these aggregated campus metrics:
- Total Students: ${cohortStats.totalStudents}
- Average Success Score: ${cohortStats.avgSuccessScore}/100
- Academic At-Risk Students: ${cohortStats.academicAtRiskCount} (${cohortStats.academicAtRiskPct}%)
- Placement At-Risk Students: ${cohortStats.placementAtRiskCount} (${cohortStats.placementAtRiskPct}%)
- Average Attendance: ${cohortStats.avgAttendance}%
- Average LMS Completion: ${cohortStats.avgLmsCompletion}%
- Average Coding Score: ${cohortStats.avgCodingScore}/100
- Department Breakdown: ${JSON.stringify(cohortStats.deptSummary)}

Provide an executive institutional briefing in JSON:
{
  "headline": "A sharp, data-driven 10-word headline for the Academic Council",
  "criticalFindings": ["3 key observations on academic health, placement readiness, and LMS engagement"],
  "systemicRisks": ["2 systemic hazards (e.g. attendance dips preceding mid-terms, gap between high CGPA and low coding skill)"],
  "strategicRecommendations": ["3 high-impact administrative policies or interventions for this semester"],
  "expectedImpact": "Projected improvement in placement rate and pass percentage if recommendations are adopted"
}
Return valid raw JSON only without markdown formatting.`;

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = generateDeterministicCohortSummary(cohortStats);
    }

    return res.json({
      source: 'gemini-3.8-flash',
      summary: parsed,
    });
  } catch (error: any) {
    console.error('Error generating cohort summary:', error);
    const fallback = generateDeterministicCohortSummary(req.body?.cohortStats);
    return res.json({
      source: 'fallback-engine',
      summary: fallback,
      errorNote: error.message || 'Gemini service unreachable',
    });
  }
});

function generateDeterministicStudentAdvice(student: any, targetCompanyTier = 'Tier-1 Tech Companies') {
  if (!student) {
    return {
      summary: 'Profile evaluation ready. Focus on balancing academic consistency with structured coding practice.',
      rootCauses: ['Attendance variability', 'Unbalanced placement preparation', 'LMS activity lag'],
      academicActionPlan: ['Attend remedial tutoring sessions', 'Maintain at least 80% weekly attendance'],
      placementActionPlan: ['Complete 5 LeetCode Mediums weekly', 'Practice mock behavioural interviews', 'Build a portfolio project'],
      recommendedIntervention: 'Peer Mentorship & Coding Cohort',
      encouragementQuote: 'Consistent daily effort builds unstoppable academic and professional momentum.',
    };
  }

  const causes: string[] = [];
  if (student.attendance < 75) causes.push(`Low attendance (${student.attendance}%) creates severe exam detention risk.`);
  if (student.backlogs > 0) causes.push(`Has ${student.backlogs} active backlog(s), disqualifying from 65% of campus drives.`);
  if (student.codingScore < 60) causes.push(`Coding assessment score (${student.codingScore}/100) is below industry recruitment cutoff (70+).`);
  if (student.lmsCompletion < 70) causes.push(`LMS assignment submission (${student.lmsCompletion}%) reflects inconsistent weekly engagement.`);
  if (causes.length === 0) causes.push('Solid foundational performance with opportunity for advanced competitive distinction.');

  return {
    summary: `${student.name} holds a Success Score of ${student.successScore}/100 with ${student.academicRisk.toLowerCase()} academic risk and ${student.placementRisk.toLowerCase()} placement risk for ${targetCompanyTier}.`,
    rootCauses: causes.slice(0, 3),
    academicActionPlan: [
      student.attendance < 75 ? 'Engage with Academic Counselor to map attendance recovery schedule.' : 'Focus on elevating internal assessment marks in core subjects.',
      student.backlogs > 0 ? 'Enroll in special weekend remedial clearing classes for backlogged papers.' : 'Target top 10 percentile in upcoming semester examinations.'
    ],
    placementActionPlan: [
      student.codingScore < 70 ? 'Complete 25 Data Structure & Algorithm problems (Trees, DP, Graphs) on LeetCode.' : 'Advance to system design fundamentals and concurrency patterns.',
      student.mockInterviewRating < 3.5 ? 'Schedule 2 mock technical interviews with Alumni Mentorship network.' : 'Refine STAR-method responses for behavioural and leadership interviews.',
      'Complete and deploy 1 end-to-end fullstack or AI portfolio project with live URL & GitHub docs.'
    ],
    recommendedIntervention: student.successScore < 55 ? 'Mandatory Dean Academic Advisory & Remedial Lab' : student.codingScore < 65 ? 'Targeted Coding Accelerator & Mock Drill' : 'Dream Tier-1 Fast-Track Mentorship',
    encouragementQuote: `${student.name} has demonstrated real strengths in ${student.skills?.technical?.[0] || 'core disciplines'}; targeted consistency over the next 4 weeks will unlock massive growth!`,
  };
}

function generateDeterministicCohortSummary(stats: any) {
  return {
    headline: `Campus Health Index: ${stats.avgSuccessScore}/100 Avg Success with ${stats.placementAtRiskPct}% Placement Risk Exposure`,
    criticalFindings: [
      `${stats.academicAtRiskCount} students (${stats.academicAtRiskPct}%) are flagged at academic risk, predominantly driven by attendance below 75%.`,
      `${stats.placementAtRiskCount} students (${stats.placementAtRiskPct}%) lack competitive coding or aptitude readiness for upcoming campus recruitment.`,
      `Average LMS assignment completion stands at ${stats.avgLmsCompletion}%, showing moderate digital engagement with room for gamification.`
    ],
    systemicRisks: [
      'Disparity between theoretical CGPA and hands-on coding proficiency in 3rd year cohorts.',
      'Attendance drop-offs clustering immediately prior to mid-term assessments.'
    ],
    strategicRecommendations: [
      'Institute mandatory "CodeSprint 45" daily coding hour for 5th & 7th semester batches.',
      'Automate WhatsApp/SMS attendance triggers to parents and faculty advisors when attendance dips below 78%.',
      'Deploy peer-assisted study groups paired with high-performing student mentors for at-risk courses.'
    ],
    expectedImpact: 'Projected 18% reduction in exam detention and 24% uplift in Day-1 company placement clearance.'
  };
}

// Start Server with Vite Middleware
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
    app.get('*', (req, res) => {
      res.sendFile('dist/index.html', { root: '.' });
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Smart Campus Analytics Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
